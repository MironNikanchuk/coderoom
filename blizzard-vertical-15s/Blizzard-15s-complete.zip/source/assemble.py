"""Native vertical composite + mild two-sample shutter integration + H.264/AAC."""
from pathlib import Path
import subprocess,os,json,sys
from PIL import Image
ROOT=Path(__file__).parent.resolve();OUT=Path(sys.argv[1]).expanduser().resolve() if len(sys.argv)>1 else ROOT/'output';OUT.mkdir(parents=True,exist_ok=True)
dest=ROOT/'encoded-frames';dest.mkdir(exist_ok=True)
windows=[(1.4,3.15),(3.15,4.15),(5.55,6.25),(8.45,9.2),(10.9,12.2)]
for i in range(900):
 p=ROOT/'frames'/f'{i:05d}.jpg';q=dest/p.name
 if q.exists():q.unlink()
 t=i/60
 if i>0 and any(a<t<b for a,b in windows):
  prev=Image.open(ROOT/'frames'/f'{i-1:05d}.jpg').convert('RGB');current=Image.open(p).convert('RGB')
  Image.blend(prev,current,.82).save(q,quality=96,subsampling=0)
 else:os.link(p,q)
print('Prepared 900 complete frames',flush=True)
command=['ffmpeg','-v','error','-framerate','60','-start_number','0','-i',str(dest/'%05d.jpg'),'-i',str(ROOT/'assets/soundtrack.wav'),'-map','0:v:0','-map','1:a:0','-frames:v','900','-t','15','-vf','scale=in_range=full:out_range=tv,format=yuv420p','-c:v','libx264','-preset','medium','-crf','17','-color_range','tv','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-c:a','aac','-b:a','192k','-ar','48000','-movflags','+faststart','-metadata','title=blzrd. — Следующий запуск','-metadata','comment=15 seconds. Original 3D device geometry and score; client brand assets.','-y',str(OUT/'Blizzard-15s-9x16.mp4')]
subprocess.run(command,check=True)
print(json.dumps({'file':str(OUT/'Blizzard-15s-9x16.mp4'),'bytes':(OUT/'Blizzard-15s-9x16.mp4').stat().st_size}),flush=True)
