"""Deterministic 60fps capture. Native output/typography, configurable 3D sampling."""
import asyncio,threading,http.server,functools,time,json,base64,sys
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).parent.resolve();(ROOT/'frames').mkdir(exist_ok=True);(ROOT/'review').mkdir(exist_ok=True)
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
 def copyfile(self,source,outputfile):
  try:super().copyfile(source,outputfile)
  except (BrokenPipeError,ConnectionResetError):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(ROOT)))
threading.Thread(target=server.serve_forever,daemon=True).start()
async def main():
 start=time.time();errors=[];scale='.85'
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist','--hide-scrollbars'])
  async def worker(idx,lo,hi):
   page=await browser.new_page(viewport={'width':1080,'height':1920},device_scale_factor=1)
   page.on('pageerror',lambda e:errors.append(str(e)))
   await page.goto(f'http://127.0.0.1:{server.server_port}/index.html?record=1&scale={scale}')
   await page.wait_for_function('window.ready===true',timeout=120000)
   cdp=await page.context.new_cdp_session(page)
   done=0
   for i in range(lo,hi):
    path=ROOT/'frames'/f'{i:05d}.jpg'
    if path.exists() and '--force' not in sys.argv:continue
    await page.evaluate('(t)=>renderAt(t)',i/60)
    data=await cdp.send('Page.captureScreenshot',{'format':'jpeg','quality':96,'captureBeyondViewport':False,'fromSurface':True})
    path.write_bytes(base64.b64decode(data['data']));done+=1
    if done%20==0 or done==1:print(json.dumps({'worker':idx,'frame':i,'new_frames':done,'elapsed_s':round(time.time()-start,1)}),flush=True)
   await page.close()
  if '--range' in sys.argv:
   j=sys.argv.index('--range');await worker(2,int(sys.argv[j+1]),int(sys.argv[j+2]))
  elif '--probe' in sys.argv:await worker(0,390,510)
  else:await asyncio.gather(worker(0,0,450),worker(1,450,900))
  await browser.close()
 report={'frames_present':len(list((ROOT/'frames').glob('*.jpg'))),'errors':errors,'elapsed_s':round(time.time()-start,1),'output':[1080,1920],'three_sampling_scale':float(scale),'fps':60}
 (ROOT/'review'/('patch-render.json' if '--range' in sys.argv else 'probe-render.json' if '--probe' in sys.argv else 'render-report.json')).write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
asyncio.run(main())
