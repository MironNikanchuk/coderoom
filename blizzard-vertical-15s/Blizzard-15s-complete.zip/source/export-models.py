import asyncio,threading,http.server,functools,base64,json
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).parent.resolve();(ROOT/'models').mkdir(exist_ok=True)
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(ROOT)))
threading.Thread(target=server.serve_forever,daemon=True).start()
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
  page=await b.new_page(viewport={'width':540,'height':960})
  await page.goto(f'http://127.0.0.1:{server.server_port}/index.html?record=1&scale=.5');await page.wait_for_function('window.ready===true',timeout=120000)
  for name in ['phone','notebook']:
   data=await page.evaluate('(name)=>exportDevice(name)',name)
   path=ROOT/'models'/f'blzrd-{name}.glb';path.write_bytes(base64.b64decode(data));print(json.dumps({'file':path.name,'bytes':path.stat().st_size}),flush=True)
  await b.close()
asyncio.run(main())
