import * as THREE from 'three';
import {RoundedBoxGeometry} from 'three/addons/geometries/RoundedBoxGeometry.js';
import {RoomEnvironment} from 'three/addons/environments/RoomEnvironment.js';

const $=id=>document.getElementById(id),C=THREE,clamp=x=>Math.max(0,Math.min(1,x)),sm=x=>{x=clamp(x);return x*x*(3-2*x)},eo=x=>1-(1-clamp(x))**4,lerp=(a,b,p)=>a+(b-a)*p;
await document.fonts.ready;
await Promise.all([document.fonts.load('700 50px Onest','Продуктblzrd'),document.fonts.load('italic 500 50px Spectral','запуск')]);
const images={};await Promise.all(['logo.png','hero.webp','agent.png','mascot.webp','levitation.webp','cryptojin.webp','shop-bot.png','ai-autoposting.png'].map(n=>new Promise((resolve,reject)=>{let i=new Image();i.onload=()=>{images[n]=i;resolve()};i.onerror=()=>reject(n);i.src='assets/'+n})));
const renderer=new C.WebGLRenderer({canvas:$('view'),antialias:true,alpha:true,preserveDrawingBuffer:true,powerPreference:'high-performance'});
renderer.setSize(1080,1920,false);renderer.setPixelRatio(Number(new URLSearchParams(location.search).get('scale'))||1);renderer.setClearColor(0x06030a,0);renderer.outputColorSpace=C.SRGBColorSpace;renderer.toneMapping=C.ACESFilmicToneMapping;renderer.toneMappingExposure=1.05;
const scene=new C.Scene(),camera=new C.PerspectiveCamera(36,1080/1920,.05,100);
const env=new RoomEnvironment();
// Broad studio strips provide real reflected highlights on metal and glass.
function softbox(x,y,z,w,h,color,power=8){let b=new C.Mesh(new C.PlaneGeometry(w,h),new C.MeshBasicMaterial({color:new C.Color(color).multiplyScalar(power),side:C.DoubleSide}));b.position.set(x,y,z);b.lookAt(0,0,0);env.add(b)}
softbox(-5,3,5,3,7,'#eee5ff',3);softbox(5,1,-4,2,8,'#b454fc',6);softbox(0,8,1,7,2,'#ffffff',4);
const pmrem=new C.PMREMGenerator(renderer);scene.environment=pmrem.fromScene(env,.04).texture;scene.environmentIntensity=.85;env.dispose();pmrem.dispose();
function light(color,intensity,x,y,z){let l=new C.DirectionalLight(color,intensity);l.position.set(x,y,z);scene.add(l);return l}
light('#f7eaff',3,-4,6,7);light('#b454fc',4.5,5,1,-5);light('#8568ff',2,-4,-1,-3);light('#f1ebff',.7,2,-4,5);
const metal=new C.MeshPhysicalMaterial({color:'#55505f',metalness:1,roughness:.24,clearcoat:.3,clearcoatRoughness:.2});
const rim=new C.MeshPhysicalMaterial({color:'#9a92a3',metalness:1,roughness:.17,clearcoat:.5});
const darkMetal=new C.MeshStandardMaterial({color:'#17121f',metalness:.8,roughness:.25});
const glass=new C.MeshPhysicalMaterial({color:'#0b0711',metalness:.12,roughness:.10,clearcoat:1,clearcoatRoughness:.06});
const backglass=new C.MeshPhysicalMaterial({color:'#292030',metalness:.45,roughness:.23,clearcoat:1,clearcoatRoughness:.13});
const keymat=new C.MeshPhysicalMaterial({color:'#030205',metalness:0,roughness:.82,specularIntensity:.12});
const lensmat=new C.MeshPhysicalMaterial({color:'#11142b',metalness:.55,roughness:.06,clearcoat:1,iridescence:.7,iridescenceIOR:1.45});
const lensblack=new C.MeshStandardMaterial({color:'#050507',metalness:.2,roughness:.2});
const pearl=new C.MeshStandardMaterial({color:'#f2ebfb',metalness:.25,roughness:.3});
function shape(w,h,r){let x=-w/2,y=-h/2,s=new C.Shape();s.moveTo(x+r,y);s.lineTo(x+w-r,y);s.quadraticCurveTo(x+w,y,x+w,y+r);s.lineTo(x+w,y+h-r);s.quadraticCurveTo(x+w,y+h,x+w-r,y+h);s.lineTo(x+r,y+h);s.quadraticCurveTo(x,y+h,x,y+h-r);s.lineTo(x,y+r);s.quadraticCurveTo(x,y,x+r,y);return s}
function rounded(w,h,d,r,mat,parent,x=0,y=0,z=0){let g=new C.ExtrudeGeometry(shape(w,h,r),{depth:d-2*Math.min(.02,d*.2),bevelEnabled:true,bevelSize:Math.min(.02,d*.2),bevelThickness:Math.min(.02,d*.2),bevelSegments:3,curveSegments:14,steps:1});g.translate(0,0,-(d-2*Math.min(.02,d*.2))/2);let m=new C.Mesh(g,mat);m.position.set(x,y,z);parent.add(m);return m}
function box(w,h,d,r,mat,parent,x=0,y=0,z=0){let m=new C.Mesh(new RoundedBoxGeometry(w,h,d,3,r),mat);m.position.set(x,y,z);parent.add(m);return m}
function flat(w,h,r,mat,parent,x=0,y=0,z=0){let g=new C.ShapeGeometry(shape(w,h,r),20);let pos=g.attributes.position,uv=g.attributes.uv;for(let i=0;i<pos.count;i++)uv.setXY(i,(pos.getX(i)+w/2)/w,(pos.getY(i)+h/2)/h);let m=new C.Mesh(g,mat);m.position.set(x,y,z);parent.add(m);return m}
function cylinder(radius,depth,mat,parent,x,y,z){let m=new C.Mesh(new C.CylinderGeometry(radius,radius,depth,48),mat);m.rotation.x=Math.PI/2;m.position.set(x,y,z);parent.add(m);return m}
const phone=new C.Group();scene.add(phone);phone.name='Phone / titanium, glass, three lenses';
rounded(2.14,4.45,.23,.275,metal,phone);rounded(2.07,4.38,.035,.25,glass,phone,0,0,.125);rounded(2.05,4.36,.025,.245,backglass,phone,0,0,-.125);
// Physical rails and antenna inlays.
for(let s of [-1,1]){box(.032,.51,.075,.012,rim,phone,s*1.083,.63,0);box(.033,.28,.07,.011,rim,phone,s*1.083,-.05,0);for(let y of [-1.72,1.73])box(.034,.033,.205,.007,pearl,phone,s*1.078,y,0)}
rounded(.98,1.08,.09,.22,backglass,phone,-.43,1.47,-.19);
for(let [x,y] of [[-.66,1.75],[-.19,1.47],[-.66,1.20]]){cylinder(.189,.06,rim,phone,x,y,-.263);cylinder(.152,.066,lensblack,phone,x,y,-.28);cylinder(.115,.069,lensmat,phone,x,y,-.29);cylinder(.048,.071,lensblack,phone,x,y,-.30);cylinder(.020,.074,lensmat,phone,x+.03,y+.035,-.303)}
cylinder(.066,.035,pearl,phone,-.17,1.83,-.254);cylinder(.035,.036,lensblack,phone,-.17,1.12,-.254);
box(.28,.028,.07,.008,lensblack,phone,0,-2.236,0);
for(let s of [-1,1])for(let i=0;i<5;i++)box(.028,.028,.05,.009,lensblack,phone,s*(.34+i*.08),-2.233,0);

function canvas(w,h){let c=document.createElement('canvas');c.width=w;c.height=h;return c}
function rr(ctx,x,y,w,h,r,fill,stroke){ctx.beginPath();ctx.roundRect(x,y,w,h,r);if(fill){ctx.fillStyle=fill;ctx.fill()}if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=1.5;ctx.stroke()}}
function text(ctx,s,x,y,size=32,color='#f8f2fc',weight=400){ctx.fillStyle=color;ctx.font=`${weight} ${size}px Onest`;ctx.fillText(s,x,y)}
function cover(ctx,img,x,y,w,h){let k=Math.max(w/img.width,h/img.height),iw=img.width*k,ih=img.height*k;ctx.drawImage(img,x+(w-iw)/2,y+(h-ih)/2,iw,ih)}
function arrow(ctx,x,y,size,color){ctx.strokeStyle=color;ctx.lineWidth=size*.08;ctx.lineCap='round';ctx.lineJoin='round';ctx.beginPath();ctx.moveTo(x-size*.3,y+size*.3);ctx.lineTo(x+size*.3,y-size*.3);ctx.moveTo(x-size*.25,y-size*.3);ctx.lineTo(x+size*.3,y-size*.3);ctx.lineTo(x+size*.3,y+size*.25);ctx.stroke()}
function texture(c){let t=new C.CanvasTexture(c);t.colorSpace=C.SRGBColorSpace;t.anisotropy=Math.min(4,renderer.capabilities.getMaxAnisotropy());return t}
const phoneCanvas=canvas(640,1344),pc=phoneCanvas.getContext('2d'),phoneTex=texture(phoneCanvas);
const phoneScreen=flat(1.965,4.255,.224,new C.MeshBasicMaterial({map:phoneTex,toneMapped:false}),phone,0,0,.150);
rounded(.65,.17,.012,.082,lensblack,phone,0,1.865,.164);cylinder(.035,.014,lensmat,phone,.214,1.865,.178);
let logoTex=new C.Texture(images['logo.png']);logoTex.needsUpdate=true;logoTex.colorSpace=C.SRGBColorSpace;
let logoback=new C.Mesh(new C.PlaneGeometry(1.12,.343),new C.MeshBasicMaterial({map:logoTex,transparent:true,opacity:.8,toneMapped:false}));logoback.position.set(0,-.25,-.145);logoback.rotation.y=Math.PI;phone.add(logoback);

const laptop=new C.Group();scene.add(laptop);laptop.name='Notebook / metal, keys, articulated display';
box(5.55,.17,3.65,.08,metal,laptop);box(5.36,.018,3.48,.008,rim,laptop,0,.087,0);
box(4.44,.017,1.82,.008,darkMetal,laptop,0,.105,-.58);
const keyGeo=new RoundedBoxGeometry(.30,.045,.235,2,.015),keyTransforms=new C.Object3D(),keys=new C.InstancedMesh(keyGeo,keymat,78);
let idx=0;for(let row=0;row<6;row++)for(let col=0;col<13;col++){keyTransforms.position.set((col-6)*.332,.128,-1.26+row*.265);keyTransforms.updateMatrix();keys.setMatrixAt(idx++,keyTransforms.matrix)}laptop.add(keys);
box(1.58,.046,.235,.015,keymat,laptop,0,.128,.065);
const kb=canvas(1300,520),kx=kb.getContext('2d');kx.clearRect(0,0,1300,520);let labels=['1234567890-=<','qwertyuiop[]','asdfghjkl;','zxcvbnm,./'];
for(let row=1;row<5;row++)for(let col=0;col<13;col++){let a=(labels[row-1]||'')[col]||'';text(kx,a,col*99.7+47,row*80+48,22,'#918798',400)}
const keylabel=new C.Mesh(new C.PlaneGeometry(4.32,1.70),new C.MeshBasicMaterial({map:texture(kb),transparent:true,depthWrite:false,toneMapped:false}));keylabel.rotation.x=-Math.PI/2;keylabel.position.set(0,.154,-.60);laptop.add(keylabel);
box(1.9,.012,.93,.005,darkMetal,laptop,0,.109,.98);box(1.87,.013,.9,.005,metal,laptop,0,.113,.98);
// Speaker perforations are actual mesh details, batched in one draw.
const perforations=new C.InstancedMesh(new C.CircleGeometry(.013,6),lensblack,144);idx=0;
for(let s of [-1,1])for(let j=0;j<3;j++)for(let i=0;i<24;i++){keyTransforms.position.set(s*(2.35+j*.07),.104,-1.35+i*.072);keyTransforms.rotation.set(-Math.PI/2,0,0);keyTransforms.updateMatrix();perforations.setMatrixAt(idx++,keyTransforms.matrix)}laptop.add(perforations);
for(let side of [-1,1]){box(.02,.058,.36,.008,lensblack,laptop,side*2.78,-.005,-.96);box(.022,.05,.19,.008,lensblack,laptop,side*2.78,-.005,-.4)}
const hinge=new C.Group();hinge.position.set(0,.12,-1.70);laptop.add(hinge);hinge.name='Display hinge, real pivot';
box(5.53,3.49,.12,.055,metal,hinge,0,1.72,0);rounded(5.43,3.39,.012,.115,glass,hinge,0,1.72,.066);
const laptopCanvas=canvas(1536,960),lc=laptopCanvas.getContext('2d'),laptopTex=texture(laptopCanvas);
flat(5.19,3.24,.075,new C.MeshBasicMaterial({map:laptopTex,toneMapped:false}),hinge,0,1.73,.077);
box(.39,.08,.013,.005,lensblack,hinge,0,3.31,.09);cylinder(.015,.014,lensmat,hinge,0,3.312,.10);
const laptopBack=new C.Mesh(new C.PlaneGeometry(.94,.288),new C.MeshBasicMaterial({map:logoTex,transparent:true,opacity:.55,toneMapped:false}));laptopBack.position.set(0,1.72,-.067);laptopBack.rotation.y=Math.PI;hinge.add(laptopBack);
const hingeBar=new C.Mesh(new C.CylinderGeometry(.078,.078,4.9,40),darkMetal);hingeBar.rotation.z=Math.PI/2;hingeBar.position.set(0,.075,-1.68);laptop.add(hingeBar);

// An authored 3D pointer, not a font symbol or SVG. It interacts in screen space.
const pointerShape=new C.Shape();pointerShape.moveTo(0,0);pointerShape.lineTo(.02,-.50);pointerShape.lineTo(.15,-.36);pointerShape.lineTo(.25,-.57);pointerShape.lineTo(.34,-.52);pointerShape.lineTo(.23,-.31);pointerShape.lineTo(.43,-.30);pointerShape.closePath();
const pointer=new C.Mesh(new C.ExtrudeGeometry(pointerShape,{depth:.045,bevelEnabled:true,bevelThickness:.014,bevelSize:.012,bevelSegments:3}),new C.MeshPhysicalMaterial({color:'#f5ebfa',metalness:.25,roughness:.23,clearcoat:1,emissive:'#c7b5df',emissiveIntensity:.4,transparent:true}));scene.add(pointer);pointer.visible=false;

// Studio background, distant out-of-focus light, and contact on the ground.
const glowC=canvas(256,256),gx=glowC.getContext('2d'),grad=gx.createRadialGradient(128,128,0,128,128,128);grad.addColorStop(0,'rgba(133,40,240,.23)');grad.addColorStop(.45,'rgba(105,20,170,.08)');grad.addColorStop(1,'rgba(100,0,200,0)');gx.fillStyle=grad;gx.fillRect(0,0,256,256);
const glow=new C.Sprite(new C.SpriteMaterial({map:texture(glowC),transparent:true,depthWrite:false,blending:C.AdditiveBlending,toneMapped:false}));glow.position.set(2,0,-5);glow.scale.set(14,18,1);glow.visible=false;scene.add(glow);
const shadowC=canvas(256,256),sx=shadowC.getContext('2d'),sg=sx.createRadialGradient(128,128,0,128,128,128);sg.addColorStop(0,'rgba(0,0,0,.8)');sg.addColorStop(1,'rgba(0,0,0,0)');sx.fillStyle=sg;sx.fillRect(0,0,256,256);
let shadow=new C.Mesh(new C.PlaneGeometry(14,9),new C.MeshBasicMaterial({map:texture(shadowC),transparent:true,depthWrite:false}));shadow.rotation.x=-Math.PI/2;shadow.position.y=-3.2;shadow.visible=false;scene.add(shadow);

function phoneHero(){pc.fillStyle='#08040e';pc.fillRect(0,0,640,1344);cover(pc,images['hero.webp'],0,0,640,1344);let g=pc.createLinearGradient(0,100,0,1100);g.addColorStop(0,'#08040e00');g.addColorStop(.4,'#08040e66');g.addColorStop(1,'#08040e');pc.fillStyle=g;pc.fillRect(0,0,640,1344);pc.drawImage(images['logo.png'],40,95,178,54.5);text(pc,'Следующий',42,845,66,'#fff',700);pc.font='italic 500 73px Spectral';pc.fillStyle='#dcb3ff';pc.fillText('продукт — ваш.',42,933);rr(pc,40,1070,560,94,47,'#f5ebfa');text(pc,'Начать проект',76,1130,35,'#13091d',700);arrow(pc,546,1117,32,'#b454fc');text(pc,'blizzard.guru',43,1251,25,'#bca6ce')}
function phoneChat(t){pc.fillStyle='#09050f';pc.fillRect(0,0,640,1344);text(pc,'9:41',41,48,25,'#eee',700);rr(pc,39,127,76,76,25,'#29143d');pc.save();pc.beginPath();pc.roundRect(39,127,76,76,25);pc.clip();cover(pc,images['agent.png'],39,127,76,76);pc.restore();text(pc,'Blizzard Agent',136,158,32,'#fff',700);text(pc,'AI-помощь с проектом',136,193,23,'#9f87b4');pc.strokeStyle='#ffffff15';pc.beginPath();pc.moveTo(35,232);pc.lineTo(605,232);pc.stroke();
 rr(pc,35,275,490,138,26,'#1d122b');text(pc,'Что хотите создать?',58,333,31);text(pc,'Расскажите о задаче.',58,375,28,'#b4a0c5');
 const sent=sm((t-7.0)/.25),reply=sm((t-7.65)/.38);pc.globalAlpha=sent;rr(pc,137,465,466,107,26,'#8e38dd');text(pc,'Нужен Telegram-магазин.',160,510,27,'#fff',400);text(pc,'С оплатой и выдачей.',160,549,27,'#fff',400);pc.globalAlpha=1;
 if(t>=7.05&&t<7.65){rr(pc,37,625,128,62,22,'#1d122b');for(let i=0;i<3;i++){pc.beginPath();pc.arc(72+i*27,656,5,0,Math.PI*2);pc.fillStyle='#a785c3';pc.fill()}}
 pc.globalAlpha=reply;rr(pc,35,625,550,349,28,'#1b1128');text(pc,'Соберём план проекта.',60,680,32,'#fff',700);let rows=['Техническое задание','Оценка стоимости','Ориентир по срокам'];rows.forEach((s,i)=>{let y=745+i*72;rr(pc,59,y-25,38,38,12,'#c6ff3d');pc.strokeStyle='#17200a';pc.lineWidth=3;pc.beginPath();pc.moveTo(68,y-7);pc.lineTo(75,y);pc.lineTo(87,y-13);pc.stroke();text(pc,s,115,y+2,29,'#e9deef')});pc.globalAlpha=1;
 text(pc,'Предварительно · после уточнения задачи',39,1042,20,'#8b739f');rr(pc,30,1178,483,88,30,'#17101f','#ffffff15');let msg=t<7?'Нужен Telegram-магазин…':'Написать сообщение';text(pc,msg,53,1232,25,'#907c9e');rr(pc,534,1178,79,88,30,t>6.68&&t<7.2?'#b454fc':'#7e32eb');if(t>=7&&t<7.16){rr(pc,539,1183,69,78,25,'#7d2eb8')}arrow(pc,573,1222,33,'#fff');rr(pc,223,1302,194,6,3,'#e6dfea')}
let phoneCache='';function drawPhone(t){let key=t<5.9?'hero':t<6.68?'chat-before':t<7?'chat-hover':t<7.25?'send-'+t:t<7.65?'typing':t<8.03?'reply-'+t:'done';if(key===phoneCache)return;phoneCache=key;if(t<5.9)phoneHero();else phoneChat(t);phoneTex.needsUpdate=true}
function laptopHero(t){lc.fillStyle='#06030a';lc.fillRect(0,0,1536,960);cover(lc,images['hero.webp'],830,0,706,960);let g=lc.createLinearGradient(650,0,1230,0);g.addColorStop(0,'#06030a');g.addColorStop(1,'#06030a00');lc.fillStyle=g;lc.fillRect(0,0,1536,960);lc.drawImage(images['logo.png'],58,45,160,49);text(lc,'Услуги     Кейсы     Процесс',800,79,23,'#b6a2cc');rr(lc,1290,43,191,51,26,'#faf6fc');text(lc,'Связаться',1323,77,23,'#1b0d29',700);
 text(lc,'Команда, которая',57,290,68,'#fff',700);text(lc,'доводит',57,372,68,'#fff',700);lc.font='italic 500 80px Spectral';lc.fillStyle='#dcb3ff';lc.fillText('до продакшена.',57,463);text(lc,'Сайты. Приложения. Боты.',60,552,31,'#b8a8cf');rr(lc,58,611,349,80,40,'#f7f1fa');text(lc,'Обсудить проект',91,663,31,'#170b21',700);arrow(lc,366,652,28,'#b454fc');lc.save();lc.beginPath();lc.roundRect(59,763,1418,155,22);lc.clip();cover(lc,images['levitation.webp'],650,763,827,155);lc.restore();text(lc,'The Levitation',88,821,34,'#f6f0fa',700);text(lc,'Один из наших запусков',88,865,25,'#9e88b2')}
function laptopCatalog(t){lc.fillStyle='#08040f';lc.fillRect(0,0,1536,960);lc.drawImage(images['logo.png'],55,43,165,50);text(lc,'Каталог решений',56,177,61,'#fff',700);text(lc,'Готовый софт для ваших задач',57,233,30,'#af98c3');let shift=0;
 for(let i=0;i<2;i++){let x=56+i*735+(1-eo((t-9.0-i*.10)/.45))*140;rr(lc,x,291,702,490,30,'#150d22','#ffffff20');lc.save();lc.beginPath();lc.roundRect(x+8,299,686,326,23);lc.clip();cover(lc,images[i===0?'shop-bot.png':'ai-autoposting.png'],x+8,299,686,326);lc.restore();text(lc,i===0?'Бот-магазин':'AI-автопостинг',x+27,683,38,'#fff',700);text(lc,i===0?'Продажи в Telegram':'Контент по расписанию',x+27,736,27,'#a88cbe')}
 rr(lc,56,822,1424,90,45,'#b454fc');text(lc,'Найти своё решение',95,883,35,'#fff',700);text(lc,'@blizzstorebot',1085,879,30,'#fff');arrow(lc,1421,865,34,'#fff')}
let laptopCache='';function drawLaptop(t){let key=t<8.95?'hero':t<9.65?'catalog-'+t:'catalog-done';if(key===laptopCache)return;laptopCache=key;if(t<8.95)laptopHero(t);else laptopCatalog(t);laptopTex.needsUpdate=true}

// All transforms are analytic in time, including the real display hinge.
// [time, camera xyz + look y, phone xyz / Euler xyz / scale, notebook xyz / Euler xyz / scale, lid angle]
const poses=[
 [0,[.6,.9,10.6,.65],[.15,-.85,.2,-.10,3.9,-.28,1.15],[-.4,-5.4,-2,.0,-.25,.08,1],1.48],
 [1.35,[.1,.7,11.3,.5],[.15,-.85,.15,-.08,2.95,-.10,1.12],[-.6,-4.1,-2.2,.03,-.35,-.04,1],1.45],
 [3.0,[.5,1.4,17,.1],[1.70,-.55,1.0,.02,.15,-.18,.95],[-.35,-1.6,-1.25,.07,-.25,-.05,1],1.42],
 [4.3,[-.45,1.6,17.2,.05],[1.75,-.62,1.1,.04,-.30,-.12,.94],[-.60,-1.35,-1.3,.05,-.12,-.035,1],-.13],
 [5.55,[-.8,1.15,16.3,.1],[1.55,-.65,1.1,.015,-.15,-.08,.95],[-.8,-1.45,-1.25,.08,.08,-.025,1],-.16],
 [6.25,[.0,.55,13.6,.45],[.0,-.85,.6,-.02,.10,.045,1.02],[-4.5,-1.65,-5,.12,-.34,-.08,.75],-.16],
 [8.45,[.2,.4,13.5,.40],[-.02,-.85,.6,-.01,-.05,.012,1.02],[-4.55,-1.62,-5.1,.12,-.38,-.07,.75],-.16],
 [9.2,[-.25,2.2,16.8,.2],[3.4,-1.1,-2.3,.02,-.35,.10,.75],[-.20,-2.65,-.6,.10,-.18,.015,1.02],-.14],
 [10.9,[.15,1.7,16.5,.2],[3.5,-1.1,-2.2,.04,-.45,.13,.74],[-.12,-2.65,-.6,.10,.10,-.015,1.02],-.18],
 [12.2,[.2,.7,17.4,.10],[1.65,1.30,1.8,.02,-.35,-.09,.68],[-.55,1.30,-1.0,.13,-.28,-.06,.80],-.15],
 [13.1,[.1,.7,17.5,.1],[1.64,1.30,1.8,.02,-.29,-.075,.68],[-.56,1.30,-1.0,.13,-.23,-.05,.80],-.15],
 [15,[.1,.7,17.5,.1],[1.64,1.30,1.8,.02,-.29,-.075,.68],[-.56,1.30,-1.0,.13,-.23,-.05,.80],-.15]
];
function transform(g,v){g.position.set(v[0],v[1],v[2]);g.rotation.set(v[3],v[4],v[5]);g.scale.setScalar(v[6])}
function poseAt(t){let i=poses.findIndex((v,k)=>k<poses.length-1&&t>=v[0]&&t<poses[k+1][0]);if(i<0)i=t>=15?poses.length-2:0;let a=poses[i],b=poses[i+1],p=sm((t-a[0])/(b[0]-a[0]));let vals=[0];for(let j=1;j<=3;j++)vals[j]=a[j].map((n,k)=>lerp(n,b[j][k],p));vals[4]=lerp(a[4],b[4],p);return vals}
const windows=[[0,2.75],[2.92,5.72],[6.03,8.73],[9.05,11.25]];
function overlay(t){windows.forEach(([a,b],i)=>{let el=$('copy'+i),o=(i===0?1:sm((t-a)/.32))*(1-sm((t-b+.25)/.3));if(t<a-.2||t>b+.1)o=0;el.style.opacity=o;el.style.visibility=o>.001?'visible':'hidden';el.style.transform=`translate3d(${(1-eo((t-a)/.45))*20}px,${(1-eo((t-a)/.45))*25-sm((t-b+.3)/.4)*22}px,0)`});let end=sm((t-11.75)/.6);$('end').style.opacity=end;$('end').style.visibility=end>0?'visible':'hidden';document.querySelector('.endtitle').style.transform=`translateY(${(1-eo((t-11.75)/.75))*35}px)`;document.querySelector('.maincta').style.transform=`translateY(${(1-eo((t-12.0)/.6))*28}px)`;document.querySelector('.maincta').style.opacity=sm((t-12)/.45);document.querySelector('.altcta').style.opacity=sm((t-12.2)/.45);$('subline').style.opacity=0;$('demolabel').style.opacity=sm((t-5.9)/.2)*(1-sm((t-11.4)/.2));$('seek').value=t;$('clock').textContent=t.toFixed(1)+' / 15'}
window.renderAt=function(t){t=Math.max(0,Math.min(t,15));let v=poseAt(t);camera.position.set(v[1][0],v[1][1],v[1][2]);camera.lookAt(0,v[1][3],0);transform(phone,v[2]);transform(laptop,v[3]);if(t>10.9&&t<12.2){const arc=Math.sin(Math.PI*(t-10.9)/1.3)**2;phone.position.z+=1.8*arc;phone.position.x+=.65*arc;}hinge.rotation.x=v[4];phone.updateMatrixWorld(true);laptop.updateMatrixWorld(true);drawPhone(t);drawLaptop(t);
 pointer.visible=t>=6.25&&t<7.4;pointer.material.opacity=1-sm((t-7.2)/.2);if(pointer.visible){let p=eo((t-6.30)/.50),x=lerp(1.38,.782,p),y=lerp(-1.8,-1.74,p);let target=new C.Vector3(x,y,.25);phone.localToWorld(target);pointer.position.copy(target);pointer.rotation.copy(phone.rotation);pointer.rotation.z+=.05;let press=clamp(1-Math.abs(t-7)/.12);pointer.scale.setScalar(.68-press*.07);pointer.position.z+=.12}
 glow.position.x=2+Math.sin(t*.3)*.7;glow.material.opacity=.75+.08*Math.sin(t*.5);shadow.material.opacity=t>11.5?1-sm((t-11.5)/.6):.65;overlay(t);renderer.render(scene,camera);return true};
window.exportDevice=async function(name){const {GLTFExporter}=await import('three/addons/exporters/GLTFExporter.js');window.renderAt(4.3);const obj=(name==='phone'?phone:laptop).clone(true);obj.position.set(0,0,0);obj.rotation.set(0,0,0);obj.scale.setScalar(1);obj.updateMatrixWorld(true);const data=await new GLTFExporter().parseAsync(obj,{binary:true,onlyVisible:true,maxTextureSize:1536});const bytes=new Uint8Array(data);let str='';for(let i=0;i<bytes.length;i+=32768)str+=String.fromCharCode(...bytes.subarray(i,i+32768));return btoa(str)};
window.sceneInfo=()=>({meshes:renderer.info.render.calls,triangles:renderer.info.render.triangles,webgl:renderer.capabilities.isWebGL2,renderer:renderer.getContext().getParameter(renderer.getContext().RENDERER)});
function resize(){let k=Math.min(innerWidth/1080,innerHeight/1920);$('film').style.transform=`scale(${k})`;$('film').style.left=((innerWidth-1080*k)/2)+'px';$('film').style.top=((innerHeight-1920*k)/2)+'px'}resize();addEventListener('resize',resize);
let record=new URLSearchParams(location.search).has('record'),playing=!record,audioOn=false,current=0,last=performance.now();document.body.classList.toggle('record',record);$('play').onclick=()=>{playing=!playing;$('play').textContent=playing?'Пауза':'Пуск';if(audioOn){$('audio').currentTime=current;if(playing)$('audio').play();else $('audio').pause()}};$('seek').oninput=e=>{current=+e.target.value;window.renderAt(current);$('audio').currentTime=current};$('sound').onclick=()=>{audioOn=!audioOn;$('sound').textContent=audioOn?'Без звука':'Звук';if(audioOn){$('audio').currentTime=current;if(playing)$('audio').play()}else $('audio').pause()};
window.renderAt(0);window.ready=true;
function loop(n){if(playing){current+=(n-last)/1000;if(current>15){current=0;if(audioOn){$('audio').currentTime=0;$('audio').play()}}window.renderAt(current)}last=n;requestAnimationFrame(loop)}requestAnimationFrame(loop);