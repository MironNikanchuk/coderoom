"""15-second original studio ident: electronic score, foley, and UI accents."""
from pathlib import Path
import numpy as np
from scipy.signal import butter,sosfilt
from scipy.io.wavfile import write
ROOT=Path(__file__).parent;SR=48000;D=15;N=SR*D
music=np.zeros((N,2));sfx=np.zeros_like(music);rng=np.random.default_rng(160162)
def add(buf,y,start,amp=1,pan=0):
 i=round(start*SR)
 if i<0:y=y[-i:];i=0
 n=min(len(y),N-i)
 if n<=0:return
 y=y[:n]*amp
 if y.ndim==1:buf[i:i+n,0]+=y*np.sqrt((1-pan)/2);buf[i:i+n,1]+=y*np.sqrt((1+pan)/2)
 else:buf[i:i+n]+=y
def f(m):return 440*2**((m-69)/12)
def pluck(m,dur=1.1):
 t=np.arange(round(dur*SR))/SR
 tone=np.sin(2*np.pi*f(m)*t)+.22*np.sin(2*np.pi*f(m)*2*t)*np.exp(-t*5)+.08*np.sin(2*np.pi*f(m)*4*t)*np.exp(-t*9)
 return tone*(1-np.exp(-t*900))*np.exp(-t*5.1)*(1-np.exp(-(dur-t)*50))
chords=[[41,48,55,60,63],[37,44,51,56,60],[44,51,55,60,63],[39,46,53,58,62],[41,48,55,60,63]]
for j,(start,dur) in enumerate([(0,3.5),(3,3.5),(6,3.5),(9,3),(11.5,3.5)]):
 notes=chords[j];t=np.arange(round(dur*SR))/SR
 env=np.minimum(t/.22,1)*np.minimum((dur-t)/.9,1);pad=np.zeros((len(t),2))
 for k,m in enumerate(notes[1:]):
  for ch in range(2):pad[:,ch]+=.25*(np.sin(2*np.pi*f(m)*(1+(-1 if ch==0 else 1)*.00055)*t+k*.6)+.12*np.sin(2*np.pi*f(m)*2*t))*env
 add(music,pad,start,.15 if j<4 else .19)
 for k,at in enumerate(np.arange(start,min(start+dur-.5,13),.5)):
  if j==0 and k%2:continue
  note=notes[1+(k%4)]+12
  add(music,pluck(note),at,.105,(-.32 if k%2 else .32));add(music,pluck(note),at+.25,.028,(.5 if k%2 else -.5))
 for k,at in enumerate(np.arange(start,min(start+dur,12),.75)):
  z=np.arange(round(.7*SR))/SR
  y=(np.sin(2*np.pi*f(notes[0]-0)*z)+.12*np.sin(2*np.pi*f(notes[0])*2*z))*(1-np.exp(-z*200))*np.exp(-z*5)
  add(music,y,at,.15)
for at in np.arange(0,11.8,.5):
 t=np.arange(round(.24*SR))/SR
 phase=2*np.pi*(43*t+55*(1-np.exp(-t*40))/40)
 kick=np.sin(phase)*np.exp(-t*20)*(1-np.exp(-t*1200))
 if at%1==0:add(music,kick,at,.16 if at>=3 else .11)
 if at>=3:
  t=np.arange(round(.07*SR))/SR
  hat=sosfilt(butter(2,8500,btype='highpass',fs=SR,output='sos'),rng.normal(0,1,len(t)))*np.exp(-t*85)*(1-np.exp(-t*1500))
  add(music,hat,at+.25,.018,(-.45 if at%1 else .45))
 if at%2==1 and at>=3:
  t=np.arange(round(.15*SR))/SR;hit=rng.normal(0,1,len(t))
  y=sosfilt(butter(2,[1600,7000],btype='bandpass',fs=SR,output='sos'),hit)*np.exp(-t*35)*(1-np.exp(-t*1600))
  add(music,y,at,.026)
def sweep(at,dur=.6,amp=.04,pan=0):
 t=np.arange(round(dur*SR))/SR;y=rng.normal(0,1,len(t));y=sosfilt(butter(2,[450,5600],btype='bandpass',fs=SR,output='sos'),y)
 y*=np.sin(np.pi*t/dur)**3
 add(sfx,y,at,amp,pan)
for at,amp,pan in [(1.6,.024,-.2),(2.65,.04,.25),(5.55,.03,-.3),(8.65,.034,.3),(11.1,.041,-.15)]:sweep(at,.62,amp,pan)
# Hinge contact at the full-open settle; intentional, soft and metallic.
for at,m,amp in [(3.0,65,.06),(4.3,77,.035),(6.0,72,.05),(7.0,84,.08),(7.7,79,.065),(7.82,84,.07),(9.1,75,.045),(11.55,72,.10),(11.68,79,.08),(11.81,84,.065)]:add(sfx,pluck(m,1.4),at,amp,.1)
t=np.arange(round(.08*SR))/SR
click=(np.sin(2*np.pi*(1400*t-700*t*t))+.1*rng.normal(0,1,len(t)))*(1-np.exp(-t*1800))*np.exp(-t*85)
add(sfx,click,7.0,.12,.12)
fade=np.minimum(np.arange(N)/SR/.04,1)*np.minimum((N-np.arange(N))/SR/.85,1)
music*=fade[:,None];sfx*=fade[:,None];mix=music+sfx
scale=.82/max(.82,float(np.max(np.abs(mix))))
for name,arr in [('music',music),('sfx',sfx),('soundtrack-raw',mix)]:write(str(ROOT/'assets'/f'{name}.wav'),SR,np.int16(np.clip(arr*scale,-1,1)*32767))
print({'duration':D,'peak':float(np.max(np.abs(mix*scale))),'rms':float(np.sqrt(np.mean((mix*scale)**2)))})
