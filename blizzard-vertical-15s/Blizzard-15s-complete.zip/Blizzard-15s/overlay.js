/** blzrd. V3 — native-resolution typography and single final contact drawer.
 * Fonts: Oswald 700 / GolosText 600, both OFL. No SVG or emoji.
 * Caller owns clearing, branding and the 3D scene below this transparent pass.
 */
const C = { lime: '#C7FF00', ink: '#050505', paper: '#F4F5ED', muted: '#A4AB98' };
const clamp = (v, a=0, b=1) => Math.min(b, Math.max(a, v));
const out = p => 1-Math.pow(1-clamp(p),4);
const smooth = p => { p=clamp(p); return p*p*(3-2*p); };
function rr(ctx,x,y,w,h,r){ ctx.beginPath(); ctx.roundRect(x,y,w,h,r); }
function fitFont(ctx,text,maxWidth,size,family='Oswald',weight=700){
  ctx.font=`${weight} ${size}px "${family}"`;
  const actual=ctx.measureText(text).width;
  if(actual>maxWidth){ size*=maxWidth/actual; ctx.font=`${weight} ${size}px "${family}"`; }
  return size;
}
function arrow(ctx,x,y,size,color,width=3){
  ctx.strokeStyle=color;ctx.lineWidth=width;ctx.lineCap='square';ctx.lineJoin='miter';
  ctx.beginPath();ctx.moveTo(x-size*.34,y+size*.34);ctx.lineTo(x+size*.34,y-size*.34);
  ctx.moveTo(x-size*.28,y-size*.34);ctx.lineTo(x+size*.34,y-size*.34);ctx.lineTo(x+size*.34,y+size*.28);ctx.stroke();
}
function headline(ctx,t,from,to,lines,opts={}){
  const duration=to-from, age=t-from;
  const enter=out(age/.28), exit=1-smooth((age-duration+.14)/.14);
  if(exit<=0 || age<0) return;
  ctx.save();ctx.globalAlpha=exit;
  const x=64, y=opts.y||236, w=952, row=opts.row||181;
  lines.forEach((text,i)=>{
    const p=out((age-i*.045)/.31);
    const second=i===1;
    const size=fitFont(ctx,text,w-40,opts.sizes?.[i]||172);
    const tw=ctx.measureText(text).width;
    const panelW=Math.min(w,tw+40);
    const yy=y+i*row;
    // A cropped typographic slab travels as a single weighted element.
    ctx.save();ctx.beginPath();ctx.rect(x-2,yy-1,w+4,row+4);ctx.clip();
    const shift=(1-p)*(row+16), slide=(1-enter)*(-25+(i*40));
    ctx.translate(slide,shift);
    ctx.fillStyle=second?C.lime:C.ink;
    ctx.fillRect(x,yy,panelW,row-2);
    ctx.fillStyle=second?C.ink:C.paper;
    ctx.textBaseline='alphabetic';
    // Native Oswald is compact; baseline aligns across every scene.
    ctx.fillText(text,x+20,yy+row-30);
    ctx.restore();
  });
  const rail=out((age-.16)/.48);
  ctx.fillStyle=C.lime;ctx.fillRect(64,y+row*2+16,82+160*rail,5);
  // Compact register mark is attached to the typography, never free-floating.
  ctx.fillStyle=C.paper;ctx.fillRect(64+82+160*rail+14,y+row*2+16,5,5);
  ctx.restore();
}
function routeLabels(ctx,t){
  const p=out((t-9.8)/.28), end=1-smooth((t-11.52)/.24);
  if(p<=0||end<=0) return;
  ctx.save();ctx.globalAlpha=end;
  const y=258+(1-p)*50;
  for(const [txt,x,w,fill,textFill] of [['ГОТОВОЕ',64,445,C.lime,C.ink],['ПОД ВАС',535,481,C.ink,C.paper]]){
    rr(ctx,x,y,w,116,8);ctx.fillStyle=fill;ctx.fill();
    fitFont(ctx,txt,w-46,84);ctx.fillStyle=textFill;ctx.textBaseline='alphabetic';ctx.fillText(txt,x+23,y+89);
  }
  ctx.restore();
}
function contactRow(ctx,y,label,handle){
  const x=96,w=888,h=154;
  ctx.fillStyle=C.ink;rr(ctx,x,y,w,h,20);ctx.fill();
  ctx.fillStyle=C.muted;ctx.font='600 25px "GolosText"';ctx.textBaseline='alphabetic';ctx.fillText(label,x+30,y+43);
  fitFont(ctx,handle,w-140,61,'GolosText',600);ctx.fillStyle=C.paper;ctx.fillText(handle,x+28,y+113);
  ctx.strokeStyle='#52641B';ctx.lineWidth=2;ctx.beginPath();ctx.arc(x+w-61,y+80,31,0,Math.PI*2);ctx.stroke();
  arrow(ctx,x+w-61,y+80,25,C.lime,3);
}
function drawer(ctx,t){
  if(t<11.8) return;
  const p=clamp((t-11.8)/.5), e=1-Math.pow(1-p,5);
  const baseY=1150, y=2020+(baseY-2020)*e;
  // One panel, including all copy. No independent typewriter delays.
  const veil=ctx.createLinearGradient(0,1000,0,1920);veil.addColorStop(0,'rgba(5,5,5,0)');veil.addColorStop(.55,`rgba(5,5,5,${.5*e})`);veil.addColorStop(1,`rgba(5,5,5,${.78*e})`);
  ctx.fillStyle=veil;ctx.fillRect(0,1000,1080,920);
  ctx.save();ctx.translate(0,y-baseY);
  ctx.shadowColor='rgba(0,0,0,.7)';ctx.shadowBlur=50;ctx.shadowOffsetY=-8;
  ctx.fillStyle=C.lime;rr(ctx,64,baseY,952,580,32);ctx.fill();ctx.shadowColor='transparent';ctx.shadowBlur=0;ctx.shadowOffsetY=0;
  ctx.fillStyle=C.ink;ctx.textBaseline='alphabetic';fitFont(ctx,'ЗАПУСТИМ?',775,103);ctx.fillText('ЗАПУСТИМ?',96,1265);
  // Short index tabs belong to the drawer construction.
  ctx.fillRect(931,1190,42,7);ctx.fillRect(931,1207,42,7);
  contactRow(ctx,1296,'AI-ПОДДЕРЖКА / РАЗРАБОТКА','@blizzardagent');
  contactRow(ctx,1470,'АВТОМАГАЗИН / КАТАЛОГ','@blizzstorebot');
  ctx.fillStyle='#3B4A00';ctx.font='500 25px "GolosText"';ctx.fillText('blizzard.guru',98,1686);
  ctx.textAlign='right';ctx.font='600 23px "GolosText"';ctx.fillText('ОТКРОЙ В TELEGRAM',982,1686);ctx.textAlign='left';
  ctx.restore();
}
export function drawOverlay(ctx,t,W=1080,H=1920){
  ctx.save();ctx.scale(W/1080,H/1920);
  if(t<1.3) headline(ctx,t,-.12,1.3,['СНОВА','ВРУЧНУЮ?'],{sizes:[178,178]});
  else if(t<3.6) headline(ctx,t,1.3,3.6,['ГОТОВЫЙ','СОФТ'],{sizes:[178,178]});
  else if(t<6) headline(ctx,t,3.6,6,['ПРОДАЖИ','НА АВТОПИЛОТЕ'],{sizes:[178,141],row:181});
  else if(t<9.8) headline(ctx,t,6,9.8,['НУЖНО','СВОЁ?'],{sizes:[178,178]});
  else if(t<11.8) routeLabels(ctx,t);
  drawer(ctx,t);
  ctx.restore();
}
export default drawOverlay;
