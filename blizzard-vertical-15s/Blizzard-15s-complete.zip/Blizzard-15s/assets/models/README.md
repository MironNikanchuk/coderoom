# Client hardware for Blizzard V3

The ready-to-use `iphone.glb`, `macbook.glb` and `metadata.json` are included. Playback/rendering of the supplied scene does **not** require the large original OBJ files or Blender. The steps below are only for rebuilding the model conversions.

The source models were supplied by the client in their [GitHub release `3d`](https://github.com/MironNikanchuk/coderoom/releases/tag/3d). Download the iPhone OBJ ZIP and the MacBook OBJ from that release manually. Place them in a local `source-models/` folder beside `prepare_models.py`, using the filenames below. The original source package is not duplicated in the film ZIP.

```text
source-models/
  iphone17promax_obj.zip
  MacBook_Air_13_export.obj
```

Run these two commands from the project root. The first extracts only the silver phone OBJ/MTL and its available texture resources. The second builds the GLBs and technical review scenes. The tested Blender version is 4.3.2; Blender must provide NumPy.

```bash
unzip -j source-models/iphone17promax_obj.zip \
  'iphone17promax_silver.*' 'shell_*.png' \
  'metal_noisy_Roughness.png' 'flashlight_glass_Normal.png' \
  'grey_*.png' 'anisotropic_rotation_ramp.jpg' 'hdri_05.hdr' \
  -d source-models/iphone
```

```bash
blender -b -t 2 -P prepare_models.py -- \
  --source-dir ./source-models --output-dir ./assets/models
```

`--source-dir` is required. `--output-dir` defaults to `assets/models` beside the script; `--review-dir` defaults to `model-work` beside the script. Either can point to another writable folder. There are no workspace-specific absolute paths in the converter. Running with `-- --help` prints its CLI options.

- `iphone.glb`: original detailed iPhone, normalized to height 4.4. Display mesh `PHONE_DISPLAY`. Only the opaque front glass overlay was removed to expose the original dedicated display/camera geometry. 36 meshes, 107,166 triangles.
- `macbook.glb`: only the complete source `Top_Body.001` laptop. The original connected lid becomes `LAPTOP_HINGE`; original base and keycaps remain. Selective keycap/body LOD, restored metallic/roughness materials, weighted custom normals and exact normals on horizontal machining planes. 10 meshes, 250,051 triangles.
- `metadata.json`: GLTF Y-up/+Z front, exact open screen coordinates, UV basis and closure angle.

Assign a `MeshBasicMaterial` with a CanvasTexture to each named display; set `texture.flipY = false`. Metadata UV is Blender UV with V upward, so Canvas pixel `(x,y)` maps to `(x/W, 1-y/H)` in the metadata plane. The Mac retains its original small UV inset.

The Mac hinge opens at `rotation.x=0` and closes at `+2.00229011` radians. Display metadata is open root space; rotate points around the hinge before applying the model root transform when projecting a cursor.

Both GLBs were reimported and tested with upright TOP/ABC/BOTTOM texture markers. The lid was checked open and shut. Technical Blender previews are low-sample geometry/UV checks; the film has its own look development and lighting.

These models were provided by the client for this film. No separate standalone redistribution license was included with their source files. No CC0/MIT license is assigned to them here. See the project `ASSET-SOURCES.md` for all asset provenance and licenses.
