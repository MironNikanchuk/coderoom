"""Normalize the original score and mux the exact 900-frame, 15-second master."""
from pathlib import Path
import subprocess,json,re,sys,argparse
ROOT=Path(__file__).parent.resolve()
ap=argparse.ArgumentParser();ap.add_argument('output',nargs='?',default=str(ROOT/'output'));ap.add_argument('--audio-only',action='store_true');opts=ap.parse_args();OUT=Path(opts.output).resolve()
OUT.mkdir(parents=True,exist_ok=True)
def run(args,**kwargs):return subprocess.run(args,check=True,**kwargs)
raw=ROOT/'assets/soundtrack-raw.wav';normalized=ROOT/'assets/soundtrack.wav'
f='loudnorm=I=-16:TP=-1.5:LRA=8'
r=run(['ffmpeg','-hide_banner','-i',str(raw),'-af',f+':print_format=json','-f','null','-'],capture_output=True,text=True)
m=json.loads(re.search(r'\{[^{}]+"input_i"[^{}]+\}',r.stderr,re.S).group(0))
(ROOT/'review/loudness-measured.json').write_text(json.dumps(m,indent=2))
f+=f":measured_I={m['input_i']}:measured_LRA={m['input_lra']}:measured_TP={m['input_tp']}:measured_thresh={m['input_thresh']}:offset={m['target_offset']}:linear=true"
run(['ffmpeg','-hide_banner','-y','-i',str(raw),'-af',f,'-ar','48000','-c:a','pcm_s24le',str(normalized)])
if opts.audio_only:raise SystemExit(0)
frames=[ROOT/'frames'/f'{n:05d}.jpg' for n in range(900)]
missing=[p.name for p in frames if not p.exists()]
if missing:raise SystemExit(f'Missing {len(missing)} frames: '+','.join(missing[:20]))
video=OUT/'Blizzard-15s-9x16.mp4'
run(['ffmpeg','-hide_banner','-y','-framerate','60','-start_number','0','-i',str(ROOT/'frames/%05d.jpg'),'-i',str(normalized),'-map','0:v:0','-map','1:a:0','-frames:v','900','-t','15','-c:v','libx264','-threads','2','-preset','slow','-crf','17','-vf','scale=in_color_matrix=bt601:out_color_matrix=bt709:in_range=full:out_range=limited,setparams=range=limited:color_primaries=bt709:color_trc=bt709:colorspace=bt709','-pix_fmt','yuv420p','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-color_range','tv','-profile:v','high','-level:v','4.2','-r','60','-c:a','aac','-b:a','256k','-ar','48000','-ac','2','-movflags','+faststart',str(video)])
print(video)
