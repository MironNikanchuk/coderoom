"""Prepare the client's real OBJ release assets for the Blizzard V3 film.
Run: blender -b -t 2 -P prepare_models.py -- --source-dir ./source-models
No procedural substitute hardware is generated. Coordinates below are GLTF Y-up.
"""
import bpy, math, json, time, argparse, sys
from pathlib import Path
from mathutils import Vector, Matrix
import numpy as np
ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.RawDescriptionHelpFormatter)
parser.add_argument('--source-dir',type=Path,required=True,help='Directory containing MacBook_Air_13_export.obj and iphone/iphone17promax_silver.obj (+ MTL/texture files).')
parser.add_argument('--output-dir',type=Path,default=ROOT/'assets/models',help='GLB + metadata destination; default: assets/models beside this script.')
parser.add_argument('--review-dir',type=Path,default=ROOT/'model-work',help='Technical previews and editable Blender scenes; default: model-work beside this script.')
argv=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
args=parser.parse_args(argv)
SRC=args.source_dir.expanduser().resolve()
PHONE_OBJ=SRC/'iphone/iphone17promax_silver.obj'
MAC_OBJ=SRC/'MacBook_Air_13_export.obj'
for source in [PHONE_OBJ,MAC_OBJ]:
 if not source.is_file():parser.error('Required source is missing: '+str(source)+'; see assets/models/README.md for the source layout.')
OUT=args.output_dir.expanduser().resolve();OUT.mkdir(parents=True,exist_ok=True)
REVIEW=args.review_dir.expanduser().resolve();REVIEW.mkdir(parents=True,exist_ok=True)
meta={'source':'https://github.com/MironNikanchuk/coderoom/releases/tag/3d','license_note':'User supplied for this film. No standalone redistribution license supplied.','coordinates':'glTF Y-up; screen front +Z; dimensions normalized independently.'}

def v(a):return [round(float(x),7) for x in a]
def reset():bpy.ops.wm.read_factory_settings(use_empty=True)
def active(o):
 bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o

def apply(o):active(o);bpy.ops.object.transform_apply(location=True,rotation=True,scale=True)
def empty(name):
 o=bpy.data.objects.new(name,None);bpy.context.scene.collection.objects.link(o);return o

def mat(name,color,metal=.0,rough=.3,emit=False):
 m=bpy.data.materials.new(name);m.use_nodes=True;n=m.node_tree.nodes;p=n.get('Principled BSDF')
 p.inputs['Base Color'].default_value=(*color,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough
 if emit:
  n.remove(p);e=n.new('ShaderNodeEmission');e.inputs['Color'].default_value=(*color,1);m.node_tree.links.new(e.outputs[0],n.get('Material Output').inputs['Surface'])
 return m

def bbox(objects):
 pts=[o.matrix_world@Vector(c) for o in objects if o.type=='MESH' for c in o.bound_box]
 return Vector([min(p[i] for p in pts) for i in range(3)]),Vector([max(p[i] for p in pts) for i in range(3)])
def gl(v):return Vector((v[0],v[2],-v[1]))
def screen_info(o):
 uv=o.data.uv_layers.active;A=[];B=[]
 for p in o.data.polygons:
  for li in p.loop_indices:
   u=uv.data[li].uv;point=o.matrix_world@o.data.vertices[o.data.loops[li].vertex_index].co
   A.append((float(u.x),float(u.y),1));B.append(tuple(gl(point)))
 A=np.asarray(A);B=np.asarray(B);coef=np.linalg.lstsq(A,B,rcond=None)[0]
 def point(u,vv):return v(np.array([u,vv,1])@coef)
 lo,hi=bbox([o])
 return {'name':o.name,'cornersUV':{'bottomLeft':point(0,0),'bottomRight':point(1,0),'topLeft':point(0,1),'topRight':point(1,1)},'center':point(.5,.5),'uVector':v(coef[0]),'vVector':v(coef[1]),'physicalAspect':float(np.linalg.norm(coef[0])/np.linalg.norm(coef[1])),'uvRange':[[float(A[:,0].min()),float(A[:,1].min())],[float(A[:,0].max()),float(A[:,1].max())]],'boundsBlender':[v(lo),v(hi)]}
def export(path):
 bpy.ops.object.select_all(action='DESELECT')
 for o in bpy.context.scene.objects:
  if o.type in {'MESH','EMPTY'}:o.select_set(True)
 bpy.ops.export_scene.gltf(filepath=str(path),export_format='GLB',use_selection=True,export_yup=True,export_apply=True,export_extras=True,export_cameras=False,export_lights=False,export_animations=False)

def preview(tag,look,camloc,ortho=6.7):
 scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=12;scene.cycles.use_denoising=False
 scene.render.resolution_x=720;scene.render.resolution_y=720;scene.render.resolution_percentage=100
 scene.world=bpy.data.worlds.new('studio_world');scene.world.color=(.08,.08,.08)
 data=bpy.data.cameras.new('check_camera');camera=bpy.data.objects.new(data.name,data);scene.collection.objects.link(camera);scene.camera=camera
 camera.location=camloc;camera.rotation_euler=(Vector(look)-camera.location).to_track_quat('-Z','Y').to_euler();data.type='ORTHO';data.ortho_scale=ortho
 for i,(pos,power,size) in enumerate([((-4,-5,7),1000,5),((4,1,5),1400,4),((-4,3,2),600,3)]):
  d=bpy.data.lights.new('softbox_'+str(i),'AREA');o=bpy.data.objects.new(d.name,d);scene.collection.objects.link(o);o.location=pos;o.rotation_euler=(Vector(look)-o.location).to_track_quat('-Z','Y').to_euler();d.energy=power;d.size=size
 scene.view_settings.view_transform='AgX';scene.render.image_settings.file_format='PNG';scene.render.filepath=str(REVIEW/(tag+'.png'));bpy.ops.render.render(write_still=True)
 for o in list(scene.objects):
  if o.type in {'CAMERA','LIGHT'}:bpy.data.objects.remove(o,do_unlink=True)

# iPhone geometry already has correct world axes after OBJ importer. Rotate into
# Blender Z-up/front -Y before GLTF axis conversion, without altering UVs.
reset();bpy.ops.wm.obj_import(filepath=str(PHONE_OBJ),use_split_objects=True,use_split_groups=True)
objs=[o for o in bpy.context.scene.objects if o.type=='MESH']
for o in objs:apply(o)
lo,hi=bbox(objs);scale=4.4/(hi.y-lo.y);center=(lo+hi)/2
rot=Matrix.Rotation(math.pi/2,4,'X')
root=empty('IPHONE_ROOT')
phone_mats={}
for o in list(objs):
 source=o.name.lower()
 for vert in o.data.vertices:vert.co=rot@((vert.co-center)*scale)
 o.parent=root
 # Original front glass includes an opaque screen-covering surface. Remove only
 # that glass shell to expose the original dedicated display/camera geometry.
 if 'front_glass' in source:
  bpy.data.objects.remove(o,do_unlink=True);continue
 if 'display' in source:
  o.name='PHONE_DISPLAY';m=mat('PHONE_DISPLAY_UI',(0.025,.03,.025),emit=True)
 else:
  o.name='PHONE_'+source.split('iphone17promax_')[-1].split()[0].upper()
  if 'black' in source or 'mic' in source or 'lines' in source:color=(.006,.008,.01);metal=.15;rough=.35
  elif 'glass' in source or 'lens' in source:color=(.008,.015,.025);metal=.45;rough=.09
  elif 'gold' in source:color=(.44,.29,.09);metal=.9;rough=.25
  elif 'white' in source:color=(.75,.78,.8);metal=.05;rough=.3
  else:color=(.29,.32,.34);metal=.88;rough=.24
  key=(color,metal,rough)
  if key not in phone_mats:phone_mats[key]=mat('Titanium_'+str(len(phone_mats)),color,metal,rough)
  m=phone_mats[key]
 o.data.materials.clear();o.data.materials.append(m)
 for p in o.data.polygons:p.material_index=0;p.use_smooth=True
bpy.context.view_layer.update()
display=bpy.data.objects['PHONE_DISPLAY'];meta['iphone']={'file':'iphone.glb','height':4.4,'screen':screen_info(display),'root':'IPHONE_ROOT','frontGlassRemoved':True,'geometry':'36 original OBJ parts; no substitute silhouette'}
export(OUT/'iphone.glb')
bpy.ops.wm.save_as_mainfile(filepath=str(REVIEW/'iphone-source.blend'))
preview('iphone-prepared',(0,0,0),(3,-8,3),5.3)
print('PHONE_EXPORTED',flush=True)

# One actual MacBook. Loose-part split is exact topology: the large connected
# lid is one component, base a second, and each real rounded key a component.
reset();bpy.ops.wm.obj_import(filepath=str(MAC_OBJ),use_split_objects=True,use_split_groups=True)
chosen=bpy.data.objects['Top_Body.001']
for o in list(bpy.context.scene.objects):
 if o!=chosen:bpy.data.objects.remove(o,do_unlink=True)
apply(chosen)
lo,hi=bbox([chosen]);scale=5.6/(hi.x-lo.x);xc=(lo.x+hi.x)/2
# Base rests on Y=0 in glTF, hinge depth Z=0.
for vert in chosen.data.vertices:
 vert.co.x=(vert.co.x-xc)*scale;vert.co.y*=scale;vert.co.z=(vert.co.z-lo.z)*scale
apply(chosen)
active(chosen);bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.mesh.separate(type='LOOSE');bpy.ops.object.mode_set(mode='OBJECT')
parts=[o for o in bpy.context.scene.objects if o.type=='MESH']
root=empty('MACBOOK_ROOT');base=empty('LAPTOP_BASE');base.parent=root;hinge=empty('LAPTOP_HINGE');hinge.parent=root
# Original slanted screen is about 114.72 degrees from its shut position.
hinge.location=(0,.018*scale,(.070-lo.z)*scale)
bpy.context.view_layer.update()
baseparts=[];lidparts=[]
for o in parts:
 lo2,hi2=bbox([o]);is_lid=hi2.z>1
 o.parent=hinge if is_lid else base
 if is_lid:
  o.matrix_parent_inverse=hinge.matrix_world.inverted();lidparts.append(o)
 else:baseparts.append(o)
# Separate materials so screen can receive an independent unlit CanvasTexture.
for o in list(parts):
 active(o);bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.mesh.separate(type='MATERIAL');bpy.ops.object.mode_set(mode='OBJECT')
parts=[o for o in bpy.context.scene.objects if o.type=='MESH'];palette={}
for o in parts:
 if not o.data.polygons:continue
 old=o.data.materials[o.data.polygons[0].material_index].name
 if old=='Screen_Emitter':
  o.name='LAPTOP_DISPLAY';material=mat('LAPTOP_DISPLAY_UI',(.035,.04,.03),emit=True)
 elif old=='Keyboard':
  o.name='MAC_KEY';material=palette.setdefault('key',mat('Keyboard_Graphite',(.008,.010,.012),.08,.39)) if 'key' not in palette else palette['key']
  # Dense source keycaps have >4700 quads each. Collapse retains rounded
  # perimeter/relief, reducing the original 385k quad keyboard substantially.
  active(o);mod=o.modifiers.new('Keycap_LOD','DECIMATE');mod.ratio=.13;bpy.ops.object.modifier_apply(modifier=mod.name)
 elif old=='TouchPad':
  o.name='MAC_TRACKPAD';material=palette.setdefault('pad',mat('Trackpad',(.22,.235,.245),.72,.32)) if 'pad' not in palette else palette['pad']
 elif old in {'Screen_Mat','Screen_Mat_Text','Knurling'}:
  o.name='MAC_'+old.upper();material=palette.setdefault('black',mat('Bezel_and_details',(.008,.01,.012),.15,.29)) if 'black' not in palette else palette['black']
 else:
  o.name='MAC_ALUMINIUM';material=palette.setdefault('body',mat('Anodized_graphite_aluminium',(.19,.215,.23),.88,.245)) if 'body' not in palette else palette['body']
  active(o);mod=o.modifiers.new('Body_LOD','DECIMATE');mod.ratio=.45;bpy.ops.object.modifier_apply(modifier=mod.name)
 o.data.materials.clear();o.data.materials.append(material)
 for p in o.data.polygons:p.material_index=0;p.use_smooth=True
# Join keycaps into a single draw-call, retaining all real geometric keycaps.
keys=[o for o in bpy.context.scene.objects if o.type=='MESH' and o.name.startswith('MAC_KEY')]
if keys:
 bpy.ops.object.select_all(action='DESELECT')
 for o in keys:o.select_set(True)
 bpy.context.view_layer.objects.active=keys[0];bpy.ops.object.join();keys[0].name='MAC_KEYBOARD'
# Area/angle-weighted split normals preserve machined planes after source LOD.
for o in bpy.context.scene.objects:
 if o.type!='MESH' or o.name=='LAPTOP_DISPLAY':continue
 active(o);mod=o.modifiers.new('Machined_surface_weighted_normals','WEIGHTED_NORMAL');mod.mode='FACE_AREA_WITH_ANGLE';mod.weight=100;mod.thresh=.01;mod.keep_sharp=True
 bpy.ops.object.modifier_apply(modifier=mod.name)
 if o.name.startswith('MAC_ALUMINIUM') or o.name=='MAC_TRACKPAD':
  me=o.data;me.update();normals=[tuple(c.vector) for c in me.corner_normals]
  for p in me.polygons:
   if abs(p.normal.z)>.9999:
    for li in p.loop_indices:normals[li]=(0.,0.,1. if p.normal.z>0 else -1.)
  me.normals_split_custom_set(normals)
bpy.context.view_layer.update();display=bpy.data.objects['LAPTOP_DISPLAY'];screen=screen_info(display)
# Compute closure angle from the real screen slope (glTF axes).
u=Vector(screen['uVector']);vv=Vector(screen['vVector']);closing=math.pi/2+math.atan2(-vv.z,vv.y)
meta['macbook']={'file':'macbook.glb','root':'MACBOOK_ROOT','width':5.6,'hinge':'LAPTOP_HINGE','hingePosition':v(gl(hinge.location)),'hingeAxis':'X','openRotationX':0,'closedRotationX':closing,'screen':screen,'screenCoordinates':'screen metadata is OPEN world coordinates before root transforms','sourceCopy':'Top_Body.001 only','baseRestY':0,'geometry':'Original connected lid, original base, original keycaps; source keyboard decimated to 13%, body45%'}
export(OUT/'macbook.glb');bpy.ops.wm.save_as_mainfile(filepath=str(REVIEW/'macbook-source.blend'))
preview('macbook-open',(0,0,1.7),(7,-10,7),7.2)
hinge.rotation_euler.x=closing;bpy.context.view_layer.update()
preview('macbook-closed',(0,-1.8,.3),(7,-10,7),7.2)
for label in ['iphone','macbook']:meta[label]['bytes']=(OUT/meta[label]['file']).stat().st_size
(OUT/'metadata.json').write_text(json.dumps(meta,indent=2));print('PREPARED',json.dumps(meta),flush=True)
