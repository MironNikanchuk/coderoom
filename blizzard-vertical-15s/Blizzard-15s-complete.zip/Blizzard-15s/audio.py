#!/usr/bin/env python3
"""Original 128 BPM / 32-beat, 15-second electronic score + timed UI foley.
No samples, downloads or copyrighted recordings. Deterministic synthesis.
Outputs 48 kHz stereo music.wav / sfx.wav / soundtrack-raw.wav.
The final video pipeline should loudness-normalize the complete mix once.
"""
from pathlib import Path
import numpy as np
from scipy import signal
from scipy.io.wavfile import write
SR=48000; DUR=15.; N=int(SR*DUR); BEAT=60/128
OUT=Path(__file__).resolve().parent/'assets';OUT.mkdir(exist_ok=True,parents=True)
rng=np.random.default_rng(20261024)
music=np.zeros((N,2),dtype=np.float64);sfx=np.zeros_like(music)
def hz(note):return 440*2**((note-69)/12)
def mono_stereo(a,pan=0):
    return np.column_stack((a*np.sqrt((1-pan)/2),a*np.sqrt((1+pan)/2)))
def add(dst,a,start,pan=0,gain=1):
    if a.ndim==1:a=mono_stereo(a,pan)
    i=round(start*SR);lo=max(i,0);hi=min(i+len(a),N)
    if hi>lo:dst[lo:hi]+=gain*a[lo-i:hi-i]
def filt(a,cut,kind='lowpass',order=2):
    return signal.sosfilt(signal.butter(order,cut,kind,fs=SR,output='sos'),a)
def tm(d):return np.arange(round(SR*d))/SR
def kick():
    t=tm(.25);freq=43+106*np.exp(-t*35)
    phase=2*np.pi*np.cumsum(freq)/SR
    env=(1-np.exp(-t*2000))*np.exp(-t*20)
    body=np.sin(phase)*env
    click=filt(rng.normal(0,1,len(t)),4500,'highpass')*np.exp(-t*700)*.13
    return np.tanh((body+click)*1.5)*.49
kick_env=np.zeros(N)
for b in range(32):
    sec=b*BEAT
    # A brief beat-free gap under the physical drawer slide makes its snap land.
    if b in (25,):continue
    add(music,kick(),sec)
    i=round(sec*SR);tt=tm(.3);ln=min(len(tt),N-i)
    kick_env[i:i+ln]=np.maximum(kick_env[i:i+ln],np.exp(-tt[:ln]*15))
    if b%4 in (1,3):
        t=tm(.17);n=filt(rng.normal(size=len(t)),[1600,10500],'bandpass')
        clap=n*np.exp(-t*33)*(1-np.exp(-t*2300))
        body=np.sin(2*np.pi*183*t)*np.exp(-t*43)
        add(music,(clap*.17+body*.07),sec,pan=.08)
        add(music,clap*.027,sec+.014,pan=-.45)
        add(music,clap*.022,sec+.027,pan=.5)
# Offbeat closed hats and a carefully spaced open top.
for k in range(64):
    sec=k*BEAT/2
    if sec>14.5:continue
    t=tm(.095 if k%2==0 else .145)
    a=filt(rng.normal(size=len(t)),[6500,17000],'bandpass',2)
    env=np.exp(-t*(88 if k%2==0 else 45))*(1-np.exp(-t*3500))
    add(music,a*env*(.057 if k%2 else .033),sec+.003,pan=(-.3 if k%4==1 else .28))
# Tight, low-mid bass sequence; sidechain is applied only to sustained layers.
bass=np.zeros_like(music)
sequence=[38,38,45,41,38,36,33,36]
for k in range(32):
    sec=k*BEAT+BEAT*.5
    if sec>14.4:continue
    note=sequence[(k//2)%8];t=tm(BEAT*.52);freq=hz(note)
    osc=np.sin(2*np.pi*freq*t)+.22*np.sin(2*np.pi*freq*2*t)+.08*np.sin(2*np.pi*freq*3*t)
    env=(1-np.exp(-t*350))*np.exp(-t*9)*np.minimum(1,(len(t)/SR-t)/.035)
    add(bass,np.tanh(osc*1.7)*env*.21,sec)
music+=bass*(1-.63*kick_env[:,None])
# Airy analog chord bed, slow stereo beating, no harsh leading sawtooth.
T=np.arange(N)/SR
pad=np.zeros((N,2))
for start,stop,chord in [(0,3.75,[50,57,60,64]),(3.75,7.5,[46,53,57,60]),(7.5,11.25,[48,55,58,62]),(11.25,15,[50,57,60,65])]:
    d=stop-start;t=tm(d);a=np.zeros((len(t),2))
    for j,note in enumerate(chord):
        f=hz(note)
        for c,detune in enumerate([-.0014,.0014]):
            ph=2*np.pi*f*(1+detune)*t+j*.7
            a[:,c]+=(np.sin(ph)+.14*np.sin(2*ph)+.04*np.sin(3*ph))/len(chord)
    env=np.minimum(1,t/.18)*np.minimum(1,(d-t)/.3)
    a*=env[:,None]*.097
    add(pad,a,start)
music+=pad*(1-.55*kick_env[:,None])
# Sparse glass plucks with stereo delay; simple original hook in D minor.
pluck_notes=[74,69,65,72,74,77,76,69]
for j,sec in enumerate([1.40625,2.34375,3.28125,4.6875,6.5625,8.4375,10.3125,12.65625]):
    t=tm(.68);f=hz(pluck_notes[j]);env=np.exp(-t*9)*(1-np.exp(-t*1800))
    a=(np.sin(2*np.pi*f*t)+.15*np.sin(2*np.pi*f*2.003*t)+.045*np.sin(2*np.pi*f*3*t))*env*.11
    add(music,a,sec,pan=-.22 if j%2 else .22)
    add(music,a,sec+BEAT*.75,pan=.62,gain=.22)
    add(music,a,sec+BEAT*1.5,pan=-.62,gain=.11)
# Functional foley: wide sweeps for physical movements, dry ticks for actions.
def sweep(d=.3,up=True,level=.2):
    t=tm(d);noise=rng.normal(size=len(t));noise=filt(noise,[500,9000],'bandpass')
    p=t/d;env=np.sin(np.pi*p)**1.5
    mod=np.sin(2*np.pi*(240*t+600*t*t/d))*.12+.88
    a=noise*env*mod*level
    # Smooth stereo trajectory gives movement without a centered white-noise blast.
    pan=(p*2-1)*(1 if up else -1)*.7
    return np.column_stack((a*np.sqrt((1-pan)/2),a*np.sqrt((1+pan)/2)))
def tick(pitch=1850):
    t=tm(.055);n=filt(rng.normal(size=len(t)),[1000,11000],'bandpass')
    return (n*.16+np.sin(2*np.pi*pitch*t)*.17)*np.exp(-t*130)*(1-np.exp(-t*5000))
def bell(note=81,d=.35):
    t=tm(d);f=hz(note)
    return (np.sin(2*np.pi*f*t)+.23*np.sin(2*np.pi*f*2.01*t))*np.exp(-t*13)*(1-np.exp(-t*2500))*.13
for sec,d,level in [(1.3,.28,.17),(3.6,.23,.13),(6.,.29,.19),(9.8,.31,.14),(11.8,.5,.21)]:
    add(sfx,sweep(d,True,level),sec-.10)
for sec in [3.35,7.35]:
    add(sfx,tick(),sec)
    add(sfx,bell(86,.11),sec+.025,gain=.34)
for sec,note in [(3.97,76),(4.57,79),(5.17,81),(8.,79),(8.7,86)]:
    add(sfx,tick(1100),sec,gain=.42)
    add(sfx,bell(note),sec+.014,pan=.12)
# One warm, weighted latch at the final drawer landing.
t=tm(.4);impact=np.sin(2*np.pi*(58*t+9*t*t))*np.exp(-t*18)*(1-np.exp(-t*2000))*.28
add(sfx,impact,12.3);add(sfx,tick(850),12.3,gain=.8)
add(sfx,bell(86,.5),12.3,pan=-.15,gain=.8);add(sfx,bell(93,.55),12.34,pan=.15,gain=.5)
# Soft tactile opening attack and coherent beat marks under the first hook.
add(sfx,tick(620),.025,gain=.7)
add(sfx,sweep(.16,False,.11),.96)
# Gentle color and a clean tail. All sources fade together to avoid truncated delays.
fade=np.ones(N);end=T>14.45;fade[end]=np.cos((T[end]-14.45)/.55*np.pi/2)**2
music*=fade[:,None];sfx*=fade[:,None]
# Stereo DC removal and mild saturation tame synthetic peaks. No brickwall normalization.
for dst in [music,sfx]:
    for c in range(2):dst[:,c]=filt(dst[:,c],28,'highpass',2)
    dst[:]=np.tanh(dst*1.12)/1.12
mix=music+sfx
peak=np.max(np.abs(mix));gain=min(1.,.88/peak)
for name,a in [('music.wav',music),('sfx.wav',sfx),('soundtrack-raw.wav',mix)]:
    write(OUT/name,SR,np.rint(np.clip(a*gain,-1,1)*32767).astype(np.int16))
print(f'Wrote 3 original stereo WAV files: {N} frames, {DUR:.3f}s, {SR} Hz. Shared gain={gain:.4f}, raw mix peak={peak:.4f}')
