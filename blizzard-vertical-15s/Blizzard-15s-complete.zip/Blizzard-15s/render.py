"""Native 1080x1920 deterministic Canvas capture, true 60fps. Local assets only."""
import asyncio,threading,http.server,functools,time,json,base64,sys,argparse
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).parent.resolve();(ROOT/'frames').mkdir(exist_ok=True);(ROOT/'review').mkdir(exist_ok=True)
ap=argparse.ArgumentParser();ap.add_argument('--probe',action='store_true');ap.add_argument('--range',nargs=2,type=int);ap.add_argument('--workers',type=int,default=2);ap.add_argument('--force',action='store_true');ap.add_argument('--scale',default=1.2,type=float);args=ap.parse_args()
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
 def copyfile(self,source,outputfile):
  try:super().copyfile(source,outputfile)
  except (BrokenPipeError,ConnectionResetError):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(ROOT)))
threading.Thread(target=server.serve_forever,daemon=True).start()
async def main():
 start=time.time();errors=[];times=[]
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=gl','--ozone-platform=headless','--ignore-gpu-blocklist','--hide-scrollbars'])
  async def worker(idx,frames):
   page=await browser.new_page(viewport={'width':1080,'height':1920},device_scale_factor=1)
   page.on('pageerror',lambda e:errors.append(str(e)))
   await page.goto(f'http://127.0.0.1:{server.server_port}/index.html?record=1&scale={args.scale}&aa=0')
   try:await page.wait_for_function('window.ready===true',timeout=180000)
   except Exception:
    print({'errors':errors,'fatal':await page.evaluate('window.fatal')},flush=True);raise
   print(json.dumps({'worker':idx,'ready_s':round(time.time()-start,1),'info':await page.evaluate('({triangles:debugScene.renderer.info.render.triangles,phone:debugScene.phoneDisplay.name,mac:debugScene.laptopDisplay.name})')}),flush=True)
   done=0
   for i in frames:
    path=ROOT/('review' if args.probe else 'frames')/(f'pilot-{i/60:05.2f}.jpg' if args.probe else f'{i:05d}.jpg')
    if path.exists() and not args.force:continue
    tick=time.time();data=await page.evaluate('(t)=>captureAt(t)',i/60);path.write_bytes(base64.b64decode(data));times.append(time.time()-tick);done+=1
    if args.probe or done%30==0 or done==1:print(json.dumps({'worker':idx,'frame':i,'t':round(i/60,3),'frame_s':round(time.time()-tick,3),'new_frames':done,'elapsed_s':round(time.time()-start,1)}),flush=True)
   if args.probe:
    (ROOT/'review'/'scene-info.json').write_text(json.dumps(await page.evaluate('({phoneAnchor:debugScene.phoneAnchor.toArray(),macAnchor:debugScene.macAnchor.toArray(),hingeX:debugScene.hinge.rotation.x,renderer:debugScene.renderer.info})'),indent=2))
   await page.close()
  if args.probe:await worker(0,[0,48,96,144,186,228,276,330,396,444,534,606,684,738,870])
  elif args.range:await worker(0,range(*args.range))
  else:await asyncio.gather(*(worker(k,range(k,900,args.workers))for k in range(args.workers)))
  await browser.close()
 report={'frames_present':len(list((ROOT/'frames').glob('*.jpg'))),'errors':errors,'elapsed_s':round(time.time()-start,1),'mean_capture_s':sum(times)/len(times) if times else 0,'output':[1080,1920],'three_sampling_scale':args.scale,'fps':60}
 (ROOT/'review'/('pilot-report.json'if args.probe else 'render-report.json')).write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
asyncio.run(main())
