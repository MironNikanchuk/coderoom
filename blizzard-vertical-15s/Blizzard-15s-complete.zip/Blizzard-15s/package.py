"""Package only reviewed, intended deliverables; never copy the whole workspace."""
from pathlib import Path
import shutil,sys,zipfile,hashlib,json
ROOT=Path(__file__).parent.resolve();OUT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT/'output';STAGE=ROOT/'release-stage/Blizzard-15s'
if STAGE.exists():shutil.rmtree(STAGE)
STAGE.mkdir(parents=True,exist_ok=True)
files=['index.html','scene.js','ui.js','overlay.js','keyboard.js','audio.py','render.py','assemble.py','validate.py','package.py','prepare_models.py','README.md','VALIDATION.md','ASSET-SOURCES.md','requirements.txt']
for file in files:shutil.copy2(ROOT/file,STAGE/file)
for folder in['assets','production']:shutil.copytree(ROOT/folder,STAGE/folder,dirs_exist_ok=True)
vendor=['vendor/package/build/three.module.js','vendor/package/build/three.core.js','vendor/package/LICENSE','vendor/package/examples/jsm/loaders/GLTFLoader.js','vendor/package/examples/jsm/utils/BufferGeometryUtils.js','vendor/package/examples/jsm/environments/RoomEnvironment.js','vendor/package/examples/jsm/geometries/RoundedBoxGeometry.js']
for file in vendor:
 dst=STAGE/file;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/file,dst)
for file in['report.json','cover.jpg']:
 dst=STAGE/'review'/file;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/'review/final'/file,dst)
video=OUT/'Blizzard-15s-9x16.mp4';shutil.copy2(video,STAGE/video.name)
paths=sorted(p for p in STAGE.rglob('*')if p.is_file())
assert all(p.suffix.lower()not in['.env','.pem','.key','.obj','.mtl']for p in paths)
assert not any(p.name in['config.yaml','.env','.DS_Store']for p in paths)
manifest={str(p.relative_to(STAGE)):hashlib.sha256(p.read_bytes()).hexdigest()for p in paths}
(STAGE/'SHA256.json').write_text(json.dumps(manifest,indent=2))
archive=OUT/'Blizzard-15s-complete.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for p in sorted(STAGE.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(STAGE.parent))
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None
 names=z.namelist();assert len(names)==len(manifest)+1
 assert 'Blizzard-15s/assets/models/macbook.glb'in names and'Blizzard-15s/assets/soundtrack.wav'in names
 assert hashlib.sha256(z.read('Blizzard-15s/'+video.name)).hexdigest()==hashlib.sha256(video.read_bytes()).hexdigest()
print(json.dumps({'archive':str(archive),'entries':len(names),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},indent=2))
