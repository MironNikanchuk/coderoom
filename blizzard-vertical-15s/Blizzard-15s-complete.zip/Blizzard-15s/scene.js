import * as THREE from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {RoundedBoxGeometry} from 'three/addons/geometries/RoundedBoxGeometry.js';
import {RoomEnvironment} from 'three/addons/environments/RoomEnvironment.js';
import {drawCatalog,drawPhone,getUIAnchors} from './ui.js';
import {addKeyLegends} from './keyboard.js';
import {drawOverlay} from './overlay.js';
const W=1080,H=1920, params=new URLSearchParams(location.search),record=params.has('record');
if(record)document.body.classList.add('record');
const out=document.getElementById('film'),ctx=out.getContext('2d',{alpha:false});
const bgCanvas=document.createElement('canvas');bgCanvas.width=W;bgCanvas.height=H;
const bgctx=bgCanvas.getContext('2d');
const scene=new THREE.Scene(),background=new THREE.Scene();
const camera=new THREE.PerspectiveCamera(34,W/H,.05,100);
const renderer=new THREE.WebGLRenderer({antialias:params.get("aa")!=="0",alpha:true,preserveDrawingBuffer:true,powerPreference:'high-performance'});
renderer.setSize(W,H);renderer.setPixelRatio(Number(params.get('scale')||1));
renderer.setClearColor(0x050505,0);renderer.outputColorSpace=THREE.SRGBColorSpace;
renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.16;
renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;
const pmrem=new THREE.PMREMGenerator(renderer);
scene.environment=pmrem.fromScene(new RoomEnvironment(),.025).texture;pmrem.dispose();
scene.environmentIntensity=.82;
const lime='#C7FF00', black='#050505';
const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
const sm=v=>{v=clamp(v);return v*v*(3-2*v)};
const ease=v=>{v=clamp(v);return v<.5?4*v*v*v:1-Math.pow(-2*v+2,3)/2};
const lerp=(a,b,t)=>a+(b-a)*t;
const v3=(a)=>new THREE.Vector3(...a);
const mat=(color,roughness=.32,metalness=.3)=>new THREE.MeshStandardMaterial({color,roughness,metalness});
const bright=new THREE.MeshBasicMaterial({color:lime,toneMapped:false});
function box(parent,w,h,d,r,material,x=0,y=0,z=0){const mesh=new THREE.Mesh(new RoundedBoxGeometry(w,h,d,2,r),material);mesh.position.set(x,y,z);parent.add(mesh);return mesh}
function light(parent,color,intensity,pos){const x=new THREE.DirectionalLight(color,intensity);x.position.set(...pos);parent.add(x);return x}
scene.add(new THREE.HemisphereLight('#eaffd8','#151910',1.45));
light(scene,'#ffffff',1.8,[-4,7,7]);light(scene,'#c7ff00',1.3,[5,1,-3]);light(scene,'#ffffff',1.1,[4,6,1]);
const key=light(scene,'#ffffff',1.1,[-3,5,6]);key.castShadow=true;
key.shadow.mapSize.set(1024,1024);Object.assign(key.shadow.camera,{left:-9,right:9,top:9,bottom:-8,near:1,far:30});key.shadow.bias=-.0002;key.shadow.normalBias=.025;
background.add(new THREE.HemisphereLight('#f4ffdf','#050505',2));light(background,'#ffffff',2,[-6,8,5]);light(background,'#c7ff00',2,[7,2,-4]);
// Three physical depths: wall / product-package trays / actual hardware.
const stage=new THREE.Group();background.add(stage);
const wallMat=mat('#0a0d08',.68,.12),edgeMat=mat('#26301a',.44,.25);
box(stage,38,28,.18,.03,wallMat,0,0,-5.4);
const lightWall=box(stage,6.2,26,.28,.12,bright,-6.4,0,-5.1);lightWall.rotation.z=-.35;
box(stage,2.6,24,.3,.08,mat('#7c9a19',.42,.15),8,-.5,-5.0).rotation.z=-.35;
for(let i=-4;i<6;i++){
 const seam=box(stage,.018,22,.07,.004,edgeMat,i*2.7,0,-5.22);seam.rotation.z=-.35;
}
const packageTrays=[];
for(let i=0;i<7;i++){
 const tray=new THREE.Group();tray.position.set((i%2?1:-1)*(2.4+(i%3)*.55),3.7-i*1.48,-1.8-(i%2)*.8);tray.rotation.set(-.09,(i%2?1:-1)*.25,(i%2?1:-1)*.12);
 box(tray,1.5,1.04,.19,.075,mat(i%3===0?'#b9eb02':'#10160c',.27,.42));
 box(tray,1.34,.87,.015,.04,mat('#060905',.4,.13),0,0,.106);
 // Embedded product module slots, kept at architectural scale.
 for(let j=0;j<3;j++)box(tray,.31,.36,.08,.035,j===0?bright:mat('#344520',.32,.2),-.4+j*.4,.04,.17);
 box(tray,.96,.037,.05,.009,bright,-.12,-.29,.17);
 stage.add(tray);packageTrays.push(tray);
}
const floor=new THREE.Mesh(new THREE.PlaneGeometry(70,60),new THREE.MeshPhongMaterial({color:'#080c05',shininess:50,specular:'#0b1204'}));floor.rotation.x=-Math.PI/2;floor.position.y=-3.1;floor.receiveShadow=true;scene.add(floor);
// Physical low platforms and neon inlay, not arbitrary floating decoration.
const podium=new THREE.Group();scene.add(podium);
box(podium,7.6,.18,4.5,.10,mat('#11180a',.24,.52),0,-2.96,-.5).receiveShadow=true;
box(podium,7.55,.025,.035,.01,bright,0,-2.88,1.7);
background.traverse(o=>{if(o.isMesh&&o.material.isMeshStandardMaterial)o.material=new THREE.MeshLambertMaterial({color:o.material.color});});
const rails=[];
for(let i=0;i<5;i++)rails.push(box(podium,.023,.012,3.2,.005,i===0?bright:mat('#30401c',.5,.2),-3.4+i*1.7,-2.856,-.5));
const laptopRoot=new THREE.Group(),phoneRoot=new THREE.Group();scene.add(laptopRoot,phoneRoot);
let laptop,phone,hinge,laptopDisplay,phoneDisplay,modelMeta;
const macUI=document.createElement('canvas');macUI.width=1536;macUI.height=960;
const phoneUI=document.createElement('canvas');phoneUI.width=750;phoneUI.height=1620;
const macCtx=macUI.getContext('2d'),phoneCtx=phoneUI.getContext('2d');
const macTexture=new THREE.CanvasTexture(macUI),phoneTexture=new THREE.CanvasTexture(phoneUI);
for(const tex of[macTexture,phoneTexture]){tex.colorSpace=THREE.SRGBColorSpace;tex.flipY=false;tex.anisotropy=Math.min(8,renderer.capabilities.getMaxAnisotropy());tex.minFilter=THREE.LinearFilter;tex.magFilter=THREE.LinearFilter;tex.generateMipmaps=false;}
const logo=new Image();logo.src='assets/logo.png';await logo.decode();
await document.fonts.load('700 120px Oswald');await document.fonts.load('600 50px GolosText');await document.fonts.ready;
const load=new GLTFLoader();
try{
 const [macFile,phoneFile,metadata]=await Promise.all([load.loadAsync('assets/models/macbook.glb'),load.loadAsync('assets/models/iphone.glb'),fetch('assets/models/metadata.json').then(r=>r.ok?r.json():{})]);
 modelMeta=metadata;laptop=macFile.scene;phone=phoneFile.scene;addKeyLegends(laptop);laptopRoot.add(laptop);phoneRoot.add(phone);
 laptop.traverse(o=>{if(o.isMesh){o.frustumCulled=true;o.castShadow=/body|frame|shell/i.test(o.name);o.receiveShadow=false;}if(/LAPTOP_DISPLAY/i.test(o.name))laptopDisplay=o;if(/LAPTOP_HINGE/i.test(o.name))hinge=o;});
 phone.traverse(o=>{if(o.isMesh){o.frustumCulled=true;o.castShadow=/body|frame|shell/i.test(o.name);}if(/PHONE_DISPLAY/i.test(o.name))phoneDisplay=o;});
 if(!laptopDisplay||!phoneDisplay||!hinge)throw Error('Required named real display or hinge missing');
 for(const [mesh,map]of[[laptopDisplay,macTexture],[phoneDisplay,phoneTexture]])mesh.material=new THREE.MeshBasicMaterial({map,toneMapped:false,side:THREE.DoubleSide});
}catch(e){window.fatal=String(e);throw e}
// Project actual UV triangle anchors from the imported display geometry.
function uvAnchor(mesh,u,v){
 const g=mesh.geometry,p=g.attributes.position,uv=g.attributes.uv,idx=g.index;
 let best=null,dist=Infinity;
 for(let i=0;i<(idx?idx.count:p.count);i+=3){
  const ids=[0,1,2].map(j=>idx?idx.getX(i+j):i+j);
  const a=new THREE.Vector2(uv.getX(ids[0]),uv.getY(ids[0])),b=new THREE.Vector2(uv.getX(ids[1]),uv.getY(ids[1])),c=new THREE.Vector2(uv.getX(ids[2]),uv.getY(ids[2]));
  const den=(b.y-c.y)*(a.x-c.x)+(c.x-b.x)*(a.y-c.y);if(Math.abs(den)<1e-12)continue;
  const wa=((b.y-c.y)*(u-c.x)+(c.x-b.x)*(v-c.y))/den,wb=((c.y-a.y)*(u-c.x)+(a.x-c.x)*(v-c.y))/den,wc=1-wa-wb;
  const outside=Math.max(0,-wa)+Math.max(0,-wb)+Math.max(0,-wc);
  if(outside<dist){best=new THREE.Vector3().fromBufferAttribute(p,ids[0]).multiplyScalar(wa).addScaledVector(new THREE.Vector3().fromBufferAttribute(p,ids[1]),wb).addScaledVector(new THREE.Vector3().fromBufferAttribute(p,ids[2]),wc);dist=outside;if(outside<1e-6)break;}
 }
 if(!best)throw Error('UV projection not found');return best;
}
const macAnchor=uvAnchor(laptopDisplay,290/1536,784/960),phoneAnchor=uvAnchor(phoneDisplay,665/750,1450/1620);
const hingeOpen=hinge.rotation.x;laptopRoot.scale.setScalar(.68);
for(const root of[laptop,phone])root.traverse(o=>{if(o.isMesh&&o.material?.isMeshStandardMaterial){if(/ALUMINIUM|TRACKPAD/.test(o.name)){o.material.color.multiplyScalar(.58);o.material.roughness=Math.max(.32,o.material.roughness);}if(/KEYBOARD/.test(o.name)){o.material.color.setRGB(.008,.009,.008);o.material.roughness=.56;o.material.metalness=.02;}}});
// All pose values are analytic: arbitrary seeks reproduce the same frame.
const shots=[
 {t:0,cam:[3.6,1.7,15.1],aim:[0,.05,0],mac:[-.6,-2.72,-.5],mr:[0,-.34,0],phone:[2.3,-.5,.8],pr:[-.08,-.48,-.18],ps:.78,lid:2.00229},
 {t:1.3,cam:[2.5,1.7,12.7],aim:[0,-.15,0],mac:[-.2,-2.72,-.6],mr:[0,-.18,0],phone:[4.8,-.6,-.5],pr:[0,-.6,-.2],ps:.74,lid:2.00229},
 {t:2.6,cam:[.30,.8,12.2],aim:[0,-.20,0],mac:[0,-2.65,0],mr:[0,-.05,0],phone:[5.9,-.5,-.9],pr:[0,-.6,-.2],ps:.74,lid:0},
 {t:3.6,cam:[.18,.65,10.6],aim:[0,-.25,0],mac:[0,-2.35,.15],mr:[0,-.025,0],phone:[6,-.5,-.9],pr:[0,-.6,-.2],ps:.74,lid:0},
 {t:5.85,cam:[-.15,.6,10.3],aim:[0,-.28,0],mac:[0,-2.30,.15],mr:[0,.025,0],phone:[5.9,-.5,-.9],pr:[0,-.6,-.2],ps:.74,lid:0},
 {t:6.65,cam:[.2,.4,10.5],aim:[0,-.25,.1],mac:[-5.4,-2.5,-1.7],mr:[0,-.48,0],phone:[.22,-1.12,.7],pr:[.025,-.08,-.035],ps:.78,lid:0},
 {t:7.35,cam:[.12,.32,10.3],aim:[0,-.30,.1],mac:[-5.6,-2.5,-1.7],mr:[0,-.52,0],phone:[.05,-1.12,.7],pr:[.01,-.035,-.012],ps:.78,lid:0},
 {t:9.65,cam:[-.10,.32,10.2],aim:[0,-.30,.1],mac:[-5.6,-2.5,-1.7],mr:[0,-.52,0],phone:[0,-1.12,.7],pr:[.01,.018,.005],ps:.78,lid:0},
 {t:10.6,cam:[1.35,1.8,14.2],aim:[0,-.2,0],mac:[-.62,-2.2,-.7],mr:[0,.13,.03],phone:[1.75,-.25,2.4],pr:[-.05,-.22,.06],ps:.56,lid:0},
 {t:11.8,cam:[.6,1.15,14.7],aim:[0,.45,0],mac:[-.55,.45,-.8],mr:[0,.10,.02],phone:[1.65,1.6,2.0],pr:[-.025,-.16,.035],ps:.56,lid:0},
 {t:12.3,cam:[.45,.9,14.8],aim:[0,.48,0],mac:[-.55,.60,-.8],mr:[0,.08,.01],phone:[1.65,1.62,2.0],pr:[-.02,-.13,.03],ps:.56,lid:0},
 {t:15,cam:[.41,.86,14.8],aim:[0,.48,0],mac:[-.55,.60,-.8],mr:[0,.08,.01],phone:[1.65,1.62,2.0],pr:[-.02,-.13,.03],ps:.56,lid:0}
];
function pose(t){let i=0;while(i<shots.length-2&&t>=shots[i+1].t)i++;let a=shots[i],b=shots[i+1],p=ease((t-a.t)/(b.t-a.t));const arr=k=>a[k].map((v,j)=>lerp(v,b[k][j],p));camera.position.fromArray(arr('cam'));camera.lookAt(v3(arr('aim')));camera.updateMatrixWorld();laptopRoot.position.fromArray(arr('mac'));if(t<2.6)laptopRoot.position.y+=.5*(1-sm((t-1.9)/.7));laptopRoot.position.y+=.30*(1-sm((t-5.85)/.8));laptopRoot.rotation.fromArray([...arr('mr'),'XYZ']);phoneRoot.position.fromArray(arr('phone'));phoneRoot.rotation.fromArray([...arr('pr'),'XYZ']);phoneRoot.scale.setScalar(lerp(a.ps,b.ps,p));hinge.rotation.x=hingeOpen+lerp(a.lid,b.lid,p);phoneRoot.visible=!(t>1.5&&t<5.9);laptopRoot.visible=!(t>6.65&&t<9.65);
 // A lime architectural wall pans behind the product during the major handoff.
 lightWall.position.x=-6.4+sm((t-5.9)/.45)*4.0-sm((t-9.8)/.8)*3.4;stage.position.x=.08*Math.sin(t*.58);stage.position.y=.06*Math.sin(t*.71);
 packageTrays.forEach((g,j)=>{g.rotation.y=(j%2?1:-1)*.25+.035*Math.sin(t*.65+j);});
 podium.visible=t<6.25;floor.visible=t<6.25;podium.position.y=laptopRoot.position.y+2.856;floor.position.y=laptopRoot.position.y-.25;
 scene.updateMatrixWorld(true);background.updateMatrixWorld(true);
}
function projected(mesh,p){const q=mesh.localToWorld(p.clone()).project(camera);return{x:(q.x*.5+.5)*W,y:(-.5*q.y+.5)*H,z:q.z}}
function cursor(x,y,click=0,alpha=1){ctx.save();ctx.translate(x,y);ctx.globalAlpha=alpha;let s=1-click*.12;ctx.scale(s,s);ctx.shadowColor='#000b';ctx.shadowBlur=13;ctx.shadowOffsetY=7;ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(9,68);ctx.lineTo(24,50);ctx.lineTo(39,79);ctx.lineTo(55,71);ctx.lineTo(40,44);ctx.lineTo(65,40);ctx.closePath();ctx.fillStyle='#f4f5ed';ctx.fill();ctx.shadowColor='transparent';ctx.lineWidth=4;ctx.lineJoin='round';ctx.strokeStyle='#050505';ctx.stroke();ctx.restore();}
function drawCursor(t){
 let mesh,anchor,start,hover,click,end,from;
 if(t>=2.67&&t<3.61){[mesh,anchor,start,hover,click,end,from]=[laptopDisplay,macAnchor,2.67,3.0,3.35,3.61,[130,-100]];}
 else if(t>=6.77&&t<7.82){[mesh,anchor,start,hover,click,end,from]=[phoneDisplay,phoneAnchor,6.77,7.02,7.35,7.82,[120,-110]];}else return;
 const p=projected(mesh,anchor),f=sm((t-start)/(hover-start));let x=p.x+from[0]*(1-f),y=p.y+from[1]*(1-f)-30*Math.sin(f*Math.PI);const press=sm((t-click)/.035)*(1-sm((t-click-.065)/.09));const exit=sm((t-click-.13)/(end-click-.13));x+=100*exit;y+=60*exit;cursor(x,y,press,1-exit);
 if(t>=click&&t<click+.23){let u=(t-click)/.23;ctx.strokeStyle=`rgba(199,255,0,${.6*(1-u)})`;ctx.lineWidth=3;ctx.beginPath();ctx.arc(p.x,p.y,14+52*u,0,Math.PI*2);ctx.stroke();}
}

function drawManualHook(t){
 if(t>1.48)return;const exit=sm((t-1.08)/.40),enter=sm((t+.04)/.25),scan=sm((t-.83)/.27);ctx.save();ctx.globalAlpha=enter*(1-exit);
 const labels=['ЗАКАЗ','ОПЛАТА','ВЫДАЧА'];
 labels.forEach((s,i)=>{const wobble=(1-scan)*Math.sin(t*9+i)*5;let x=126+i*39+(1-enter)*130,y=800+i*192-exit*200+wobble;ctx.save();ctx.translate(x,y);ctx.transform(.98,-.025,-.09,1,0,0);ctx.shadowBlur=28;ctx.shadowColor='#000b';ctx.shadowOffsetY=12;ctx.fillStyle=scan>(i+1)*.25?'#c7ff00':'#11170d';ctx.beginPath();ctx.roundRect(0,0,720,154,16);ctx.fill();ctx.shadowColor='transparent';ctx.strokeStyle='#506031';ctx.lineWidth=2;ctx.stroke();ctx.font='700 79px Oswald';ctx.fillStyle=scan>(i+1)*.25?'#050505':'#f4f5ed';ctx.fillText(s,35,107);ctx.font='600 29px GolosText';ctx.fillText('0'+(i+1),629,91);ctx.restore();});
 ctx.restore();
}

let lastBgKey='';
function drawBackground(t){
 renderer.setClearColor(0x050505,1);renderer.render(background,camera);bgctx.clearRect(0,0,W,H);bgctx.drawImage(renderer.domElement,0,0,W,H);
 // Background architecture is one measured depth plane behind the focused hardware.
 const focusDist=camera.position.distanceTo(phoneRoot.visible&&t>6?phoneRoot.position:laptopRoot.position),backDist=focusDist+5;
 const blur=clamp((backDist-focusDist)*.48,1.4,3.1);ctx.filter=`blur(${blur.toFixed(2)}px)`;ctx.drawImage(bgCanvas,-5,-5,W+10,H+10);ctx.filter='none';
}
function renderWorld(t,alpha=1){pose(t);renderer.setClearColor(0x050505,0);renderer.render(scene,camera);ctx.save();ctx.globalAlpha=alpha;ctx.drawImage(renderer.domElement,0,0,W,H);ctx.restore();}
let finalWorldCache=null;
window.renderAt=function(t){t=clamp(t,0,15);ctx.reset();ctx.imageSmoothingQuality='high';if(t>=12.3&&finalWorldCache){ctx.drawImage(finalWorldCache,0,0);pose(12.3);}else{const worldTime=Math.min(t,12.3);drawCatalog(macCtx,worldTime,1536,960,{logo});drawPhone(phoneCtx,worldTime,750,1620,{logo});macTexture.needsUpdate=true;phoneTexture.needsUpdate=true;pose(worldTime);drawBackground(worldTime);
 const blurPhase=(t>1.33&&t<2.55)||(t>5.92&&t<6.62)||(t>9.83&&t<10.58)||(t>11.32&&t<11.98);
 // Two adjacent shutter samples, only for the fast physical moves. UI typography overlay is sharp.
 if(blurPhase){renderWorld(Math.max(0,t-1/360),1);renderWorld(t,.60);}else renderWorld(worldTime,1);if(t>=12.3){finalWorldCache=document.createElement('canvas');finalWorldCache.width=W;finalWorldCache.height=H;finalWorldCache.getContext('2d').drawImage(out,0,0);}}
 // Editorial hierarchy is held on a deep-black upper field with a soft end.
 const shadeEnd=850-sm((t-10.7)/.6)*490;const shade=ctx.createLinearGradient(0,0,0,shadeEnd);shade.addColorStop(0,'#050505');shade.addColorStop(.70,'#050505');shade.addColorStop(1,'#05050500');ctx.fillStyle=shade;ctx.fillRect(0,0,W,shadeEnd);
 ctx.drawImage(logo,64,94,184,184*logo.height/logo.width);ctx.font='500 20px GolosText';ctx.fillStyle='#c7ff00';ctx.textAlign='right';ctx.fillText('СОФТ ДЛЯ ВАШЕГО БИЗНЕСА',1016,132);ctx.textAlign='left';
 drawManualHook(t);drawOverlay(ctx,t,W,H);drawCursor(t);
 // A restrained printed frame-index cue reinforces the industrial identity.
 if(t<11.8){ctx.fillStyle='#9ba78b';ctx.font='500 17px GolosText';ctx.fillText('blizzard.guru',64,1818);ctx.textAlign='right';ctx.fillText(t<6?'ГОТОВЫЕ РЕШЕНИЯ':t<9.8?'РАЗРАБОТКА ПОД ВАС':'ВЫБЕРИТЕ СВОЙ ПУТЬ',1016,1818);ctx.textAlign='left';}
 window.currentTime=t;return true;
};
window.captureAt=function(t){window.renderAt(t);return out.toDataURL('image/jpeg',.97).split(',')[1]};
window.debugScene={renderer,scene,background,camera,laptopRoot,phoneRoot,laptopDisplay,phoneDisplay,hinge,modelMeta,projected,macAnchor,phoneAnchor};
window.ready=true;window.renderAt(0);
function resize(){let k=Math.min(innerWidth/W,innerHeight/H);out.style.transform=`scale(${k})`;out.style.marginLeft=`${Math.max(0,(innerWidth-W*k)/2)}px`;}
addEventListener('resize',resize);resize();
if(!record){let playing=true,start=performance.now(),base=0,audio=document.getElementById('audio'),sound=false;const seek=document.getElementById('seek'),clock=document.getElementById('clock');function loop(now){if(playing){let t=(base+(now-start)/1000)%15;renderAt(t);seek.value=t;clock.textContent=t.toFixed(2)+' / 15';if(sound&&Math.abs(audio.currentTime-t)>.12)audio.currentTime=t;}requestAnimationFrame(loop)}requestAnimationFrame(loop);document.getElementById('play').onclick=e=>{playing=!playing;if(playing){base=window.currentTime;start=performance.now();if(sound)audio.play();}else audio.pause();e.target.textContent=playing?'Пауза':'Играть';};seek.oninput=e=>{base=+e.target.value;start=performance.now();renderAt(base);audio.currentTime=base;};document.getElementById('sound').onclick=e=>{sound=!sound;audio.currentTime=window.currentTime;if(sound&&playing)audio.play();else audio.pause();e.target.textContent=sound?'Без звука':'Звук';};}
