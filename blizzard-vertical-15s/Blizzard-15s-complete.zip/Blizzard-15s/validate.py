"""Validate the actual decoded MP4, not just the source frame count."""
from pathlib import Path
import subprocess,json,sys,hashlib,re
from PIL import Image,ImageOps,ImageDraw,ImageFont
ROOT=Path(__file__).parent.resolve();VIDEO=Path(sys.argv[1]).resolve();REVIEW=ROOT/'review/final';REVIEW.mkdir(parents=True,exist_ok=True)
def run(args):return subprocess.run(args,capture_output=True,text=True,check=True)
p=json.loads(run(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(VIDEO)]).stdout)
v=next(x for x in p['streams']if x['codec_type']=='video');a=next(x for x in p['streams']if x['codec_type']=='audio')
assert(v['width'],v['height'],v['codec_name'],v['pix_fmt'],v['avg_frame_rate'],int(v['nb_read_frames']))==(1080,1920,'h264','yuv420p','60/1',900)
assert v['color_space']=='bt709' and v['color_range']=='tv'
assert abs(float(v['duration'])-15)<.001 and a['codec_name']=='aac'and a['sample_rate']=='48000'and a['channels']==2
assert abs(float(a['duration'])-15)<.025
f=json.loads(run(['ffprobe','-v','error','-select_streams','v:0','-show_frames','-show_entries','frame=best_effort_timestamp_time','-of','json',str(VIDEO)]).stdout)['frames']
t=[float(x['best_effort_timestamp_time'])for x in f];assert len(t)==900
assert max(abs(t[i]-i/60)for i in range(900))<.00001
l=run(['ffmpeg','-hide_banner','-i',str(VIDEO),'-map','0:a:0','-af','loudnorm=I=-16:TP=-1.5:LRA=8:print_format=json','-f','null','-'])
volume=json.loads(re.search(r'\{[^{}]+"input_i"[^{}]+\}',l.stderr,re.S).group(0))
assert float(volume['input_tp'])<0,'Decoded AAC clips'
# Decode entire video and audio streams; ffmpeg errors are fatal.
run(['ffmpeg','-hide_banner','-v','error','-xerror','-i',str(VIDEO),'-map','0:v:0','-map','0:a:0','-f','null','-'])
indices=sorted(set([0,24,48,60,72,96,120,144,168,186,201,228,246,276,312,330,378,402,420,441,450,474,489,510,534,552,570,606,636,666,684,708,720,738,780,840,899]+[n for edge in[78,212,234,360,588,708,738]for n in[edge-1,edge,edge+1]]))
selection='+'.join(f'eq(n,{n})'for n in indices)
run(['ffmpeg','-hide_banner','-v','error','-y','-i',str(VIDEO),'-vf',f"select='{selection}'",'-fps_mode','passthrough','-frame_pts','1',str(REVIEW/'decoded-%05d.png')])
font=ImageFont.truetype(str(ROOT/'assets/fonts/GolosText[wght].ttf'),18)
files=sorted(REVIEW.glob('decoded-*.png'))
for k in range(0,len(files),12):
 batch=files[k:k+12];sheet=Image.new('RGB',(1080,1560),'#171b13');d=ImageDraw.Draw(sheet)
 for j,path in enumerate(batch):
  x=(j%4)*270;y=(j//4)*520;im=Image.open(path).convert('RGB');im.thumbnail((270,480),Image.Resampling.LANCZOS);sheet.paste(im,(x,y));n=int(path.stem.split('-')[-1]);d.text((x+8,y+486),f'{n:03d}  {n/60:.3f}s',font=font,fill='#c7ff00')
 sheet.save(REVIEW/f'contact-{k//12+1:02d}.jpg',quality=94)
report={'video':str(VIDEO.name),'sha256':hashlib.sha256(VIDEO.read_bytes()).hexdigest(),'bytes':VIDEO.stat().st_size,'video_stream':{k:v.get(k)for k in['codec_name','profile','width','height','pix_fmt','avg_frame_rate','nb_read_frames','duration','start_time','color_space','color_primaries','color_transfer','color_range']},'audio_stream':{k:a.get(k)for k in['codec_name','sample_rate','channels','duration','start_time']},'timestamp_max_error_s':max(abs(t[i]-i/60)for i in range(900)),'decoded_loudness':volume,'decoded_review_frames':indices,'decode_errors':0,'perceptual_limit':'Frames and technical audio metrics checked. Continuous real-time audiovisual playback and listening unavailable in the tool interface; not marked passed.'}
(REVIEW/'report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
