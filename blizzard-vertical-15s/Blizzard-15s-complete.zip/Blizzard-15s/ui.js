// Authored, deterministic Canvas UI. No bitmap banners, SVG, emoji, or dependencies.
// Canvas font families expected from host: Oswald (700), GolosText (500–600).
const P={lime:'#C7FF00',black:'#050505',white:'#F4F5ED',panel:'#111410',panel2:'#191E15',line:'#34402A',muted:'#A6AF9A',dim:'#79836E'};
const clamp=x=>Math.max(0,Math.min(1,x)),sm=x=>{x=clamp(x);return x*x*(3-2*x)},mix=(a,b,p)=>a+(b-a)*p;
function rr(c,x,y,w,h,r,fill,stroke,lw=2){c.beginPath();c.roundRect(x,y,w,h,r);if(fill){c.fillStyle=fill;c.fill()}if(stroke){c.lineWidth=lw;c.strokeStyle=stroke;c.stroke()}}
function txt(c,s,x,y,size=30,color=P.white,weight=500,family='GolosText'){c.fillStyle=color;c.font=`${weight} ${size}px "${family}"`;c.fillText(s,x,y)}
function line(c,x1,y1,x2,y2,color=P.line,width=2){c.strokeStyle=color;c.lineWidth=width;c.beginPath();c.moveTo(x1,y1);c.lineTo(x2,y2);c.stroke()}
function arrow(c,x,y,size,color=P.black){c.strokeStyle=color;c.lineWidth=Math.max(2,size*.09);c.lineJoin='round';c.lineCap='round';c.beginPath();c.moveTo(x-size*.35,y);c.lineTo(x+size*.30,y);c.moveTo(x+size*.03,y-size*.27);c.lineTo(x+size*.30,y);c.lineTo(x+size*.03,y+size*.27);c.stroke()}
function tick(c,x,y,size,color=P.black){c.strokeStyle=color;c.lineWidth=Math.max(2,size*.11);c.lineCap='round';c.lineJoin='round';c.beginPath();c.moveTo(x-size*.34,y);c.lineTo(x-size*.09,y+size*.26);c.lineTo(x+size*.37,y-size*.29);c.stroke()}
function dot(c,x,y,r,color){c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.fillStyle=color;c.fill()}
function fitImage(c,img,x,y,w,h){if(!img||!img.width||!img.height)return false;let k=Math.min(w/img.width,h/img.height);c.drawImage(img,x+(w-img.width*k)/2,y+(h-img.height*k)/2,img.width*k,img.height*k);return true}
function brand(c,x,y,w=134,assets={}){if(assets.logo&&fitImage(c,assets.logo,x,y-37,w,w*.307))return;txt(c,'blzrd',x,y,37,P.white,700,'GolosText');dot(c,x+106,y-4,5.5,P.lime)}

// Product portraits are miniature application states, not decorative pictograms.
// A host may supply clean transparent object renders in assets.shop/autopost/access.
function miniature(c,kind,x,y,w,h,assets={}){
 const key={shop:'shop',post:'autopost',access:'access'}[kind];
 if(fitImage(c,assets[key],x,y,w,h))return;
 c.save();c.translate(x,y);c.scale(w/360,h/210);
 rr(c,0,0,360,210,15,'#080B07','#39442F',2);
 rr(c,0,0,360,32,15,'#242D1A');rr(c,0,18,360,14,0,'#242D1A');
 dot(c,17,16,3.4,P.lime);dot(c,30,16,3.4,'#67754D');dot(c,43,16,3.4,'#67754D');
 if(kind==='shop'){
  txt(c,'Цифровые товары',18,59,17,P.white,600);
  txt(c,'КАТАЛОГ',275,58,10,P.muted,600);
  const formats=['PDF','KEY','ZIP'];
  for(let j=0;j<3;j++){
   let xx=18+j*111;
   rr(c,xx,76,101,108,8,j===0?'#273715':'#1D2615',j===0?'#7EA900':null,1);
   rr(c,xx+10,86,81,45,5,j===0?P.lime:'#34482A');
   txt(c,formats[j],xx+20,116,23,j===0?P.black:'#D5E8BA',700,'Oswald');
   txt(c,'Товар 0'+(j+1),xx+10,150,12,P.white,600);
   rr(c,xx+10,161,81,16,4,j===0?P.lime:'#3B4F2A');
   txt(c,'В корзину',xx+20,172,9,j===0?P.black:'#DAE7C7',600);
  }
  dot(c,23,197,3.2,P.lime);txt(c,'Оплата и автовыдача',33,201,11,P.muted,500);
 }else if(kind==='post'){
  txt(c,'Новый пост',18,59,17,P.white,600);
  rr(c,18,73,212,105,8,'#1D2615');
  txt(c,'Публикация для канала',29,95,13,P.white,600);
  txt(c,'Текст подготовлен с ИИ',29,118,11,P.muted,500);
  line(c,29,133,212,133,'#465B33',1);
  txt(c,'Готов к согласованию',29,154,11,P.lime,600);
  rr(c,244,73,98,105,8,'#29351D');
  txt(c,'РАСПИСАНИЕ',254,91,9,P.muted,600);
  for(let r=0;r<2;r++)for(let col=0;col<3;col++){
   let active=r===1&&col===1;
   rr(c,256+col*26,103+r*28,17,19,4,active?P.lime:'#4E6338');
   txt(c,String(10+r*3+col),258+col*26,116+r*28,8,active?P.black:'#D4E4BA',600);
  }
  rr(c,18,187,324,17,7,P.lime);txt(c,'Запланировано',126,199,10,P.black,600);
 }else{
  txt(c,'Доступ в закрытый канал',18,59,16,P.white,600);
  rr(c,18,73,324,59,9,'#1D2615');
  rr(c,29,84,37,37,9,P.lime);txt(c,'01',37,110,22,P.black,700,'Oswald');
  txt(c,'Участник канала',79,99,13,P.white,600);
  txt(c,'Персональная ссылка',79,119,11,P.muted,500);
  rr(c,18,146,224,48,9,'#29351D');txt(c,'Подписка активна',30,167,13,P.white,600);
  txt(c,'Продление и контроль доступа',30,185,10,P.muted,500);
  rr(c,256,146,86,48,9,P.lime);tick(c,299,170,27,P.black);
 }
 c.restore();
}

function macHeader(c,assets){rr(c,0,0,1536,960,0,P.black);brand(c,64,70,146,assets);txt(c,'Каталог',405,67,27,P.white,600);line(c,405,88,515,88,P.lime,4);txt(c,'Для бизнеса',579,67,26,P.muted);rr(c,1258,32,214,53,9,P.panel2,P.line);txt(c,'Готовый софт',1282,67,23,P.white,500);line(c,64,112,1472,112,P.line,1.5)}
const cards=[
 {kind:'shop',title:'Бот-магазин',subtitle:'Продажи в Telegram',tag:'Каталог · Оплата · Выдача'},
 {kind:'post',title:'AI-автопостинг',subtitle:'Контент по расписанию',tag:'Посты · ИИ · Расписание'},
 {kind:'access',title:'Платный доступ',subtitle:'Подписка на ваш канал',tag:'Подписка · Оплата · Доступ'}
];
function catalogGrid(c,t,assets){
 txt(c,'КАТАЛОГ РЕШЕНИЙ',64,235,82,P.white,700,'Oswald');txt(c,'Выберите инструмент под вашу задачу',67,287,30,P.muted);
 const w=452,h=500,y0=332;
 cards.forEach((item,i)=>{
  const x=64+i*478,enter=sm((t-2.05-i*.06)/.35),hover=i===0?sm((t-3.0)/.15):0,press=i===0?(1-sm((t-3.35)/.14))*sm((t-3.35)/.025):0;
  const y=y0+(1-enter)*26-hover*6;
  c.save();c.globalAlpha*=enter;c.translate(x+w/2,y+h/2);let sc=1-press*.018;c.scale(sc,sc);c.translate(-w/2,-h/2);
  rr(c,0,0,w,h,20,hover>.001?'#1A2111':P.panel,hover>.001?P.lime:P.line,hover>.001?3:2);
  txt(c,'0'+(i+1),25,44,24,hover>.001?P.lime:P.dim,600);
  miniature(c,item.kind,25,70,402,225,assets);
  txt(c,item.title,25,351,40,P.white,600);txt(c,item.subtitle,25,394,26,P.muted);
  const bx=24,by=422;rr(c,bx,by,404,58,10,i===0?P.lime:'#222B1A',i===0?null:'#3C4A2E');
  txt(c,'Подробнее',bx+21,by+39,27,i===0?P.black:P.white,600);arrow(c,bx+365,by+29,27,i===0?P.black:P.lime);
  c.restore();
 });
 txt(c,'Инструменты для автоматизации бизнеса',66,907,25,P.dim);
}

function catalogDetail(c,t,assets){
 txt(c,'БОТ-МАГАЗИН',64,230,82,P.white,700,'Oswald');txt(c,'Каталог. Оплата. Автовыдача.',67,282,31,P.muted);
 rr(c,1132,166,340,54,9,P.lime);txt(c,'ДЕМО ФУНКЦИЙ',1160,202,26,P.black,700,'Oswald');
 rr(c,64,331,500,438,20,P.panel,P.line);miniature(c,'shop',90,363,448,262,assets);txt(c,'Цифровые товары',92,686,34,P.white,600);txt(c,'Бот ведёт заказ по шагам',92,731,26,P.muted);
 rr(c,596,331,876,438,20,P.panel,P.line);txt(c,'ПРИМЕР РАБОТЫ БОТА',627,383,32,P.white,700,'Oswald');
 const times=[3.97,4.57,5.17],labels=['Заказ получен','Оплата подтверждена','Доступ выдан'],sub=['Заявка попадает в каталог заказов','Бот получает статус платежа','Ссылка, инструкция или ключ'];
 for(let i=0;i<3;i++){
  const active=sm((t-times[i])/.27),yy=449+i*101;
  if(i<2)line(c,660,yy+22,660,yy+86,active>.8?P.lime:'#35422B',3);
  rr(c,634,yy-27,52,52,13,active>.01?P.lime:'#28321F',active>.01?null:'#52643D');
  if(active>.8)tick(c,660,yy-1,24,P.black);else txt(c,'0'+(i+1),644,yy+7,20,active>.01?P.black:P.muted,600);
  c.save();c.globalAlpha*=.46+.54*active;txt(c,labels[i],709,yy+1,33,P.white,600);txt(c,sub[i],709,yy+39,23,P.muted);c.restore();
 }
 rr(c,64,814,1408,86,14,P.lime);txt(c,'Открыть каталог',95,870,35,P.black,600);txt(c,'@blizzstorebot',1090,869,28,P.black,600);arrow(c,1428,857,34,P.black);
 txt(c,'Демонстрация функций продукта',66,940,20,P.dim);
}

/** Draw a native catalogue and its selected product state at the film time t. */
export function drawCatalog(ctx,t,W=1536,H=960,assets={}){
 ctx.save();ctx.scale(W/1536,H/960);macHeader(ctx,assets);
 const p=sm((t-3.53)/.35);
 if(p<1){ctx.save();ctx.globalAlpha*=1-p;catalogGrid(ctx,t,assets);ctx.restore()}
 if(p>0){ctx.save();ctx.globalAlpha*=p;ctx.translate(0,(1-p)*24);catalogDetail(ctx,t,assets);ctx.restore()}
 ctx.restore();return getUIAnchors(W,H,'catalog');
}

function phoneFrame(c){rr(c,0,0,750,1620,0,P.black);txt(c,'9:41',48,64,25,P.white,600);rr(c,614,45,56,21,5,null,P.muted,2);rr(c,619,50,39,11,2,P.lime);rr(c,673,51,4,9,2,P.muted);rr(c,263,1569,224,6,3,'#D7DEC9')}
function queuePhone(c,t){
 txt(c,'РУЧНЫЕ ЗАДАЧИ',43,228,61,P.white,700,'Oswald');txt(c,'Каждый день по кругу',45,279,29,P.muted);
 ['Принять заказ','Ответить клиенту','Проверить оплату','Выдать доступ'].forEach((s,i)=>{
  let yy=352+i*184,progress=clamp((t-i*.18)/1.0),nudge=Math.sin(clamp((t-.1-i*.08)/.22)*Math.PI)*8;
  rr(c,42,yy+nudge,666,146,18,P.panel,P.line);txt(c,'0'+(i+1),68,yy+53+nudge,25,P.dim,600);txt(c,s,133,yy+58+nudge,34,P.white,600);rr(c,133,yy+89+nudge,520,6,3,'#2B3522');rr(c,133,yy+89+nudge,Math.max(6,520*progress),6,3,i===0?P.lime:'#677A46');
 });
 rr(c,42,1219,666,118,17,P.lime);txt(c,'МОЖНО ПРОЩЕ.',73,1299,55,P.black,700,'Oswald');
 txt(c,'Готовые инструменты для бизнеса',45,1425,27,P.muted);
}
function aiPhone(c,t){
 rr(c,42,153,78,78,18,P.lime);txt(c,'AI',58,210,40,P.black,700,'Oswald');txt(c,'BLIZZARD AGENT',142,192,40,P.white,700,'Oswald');txt(c,'Помощь с вашим проектом',144,234,27,P.muted);line(c,42,281,708,281,P.line,1.5);
 rr(c,42,335,594,158,20,P.panel);txt(c,'Что хотите создать?',69,394,34,P.white,600);txt(c,'Опишите вашу задачу.',69,443,31,P.muted);
 const sent=sm((t-7.38)/.27),reply=sm((t-8.0)/.35);
 c.save();c.globalAlpha*=sent;let uy=541+(1-sent)*14;rr(c,155,uy,553,144,20,P.lime);txt(c,'Сервис записи',181,uy+58,35,P.black,600);txt(c,'клиентов',181,uy+108,35,P.black,600);c.restore();
 if(t>=7.63&&t<8.0){rr(c,42,746,155,73,18,P.panel);for(let i=0;i<3;i++)dot(c,83+i*29,782,5.5,'#8EAB5F')}
 c.save();c.globalAlpha*=reply;rr(c,42,746+(1-reply)*14,666,535,21,P.panel);txt(c,'Соберём план проекта.',69,810,35,P.white,600);txt(c,'Уточним функции и интеграции.',69,860,27,P.muted);
 const titles=['Техническое задание','Оценка цены','Сроки'],detail=['Задача и функции','Предварительно','После уточнения деталей'];
 titles.forEach((s,i)=>{
  const p=sm((t-8.7-i*.17)/.24),y=938+i*106;c.save();c.globalAlpha*=.34+.66*p;
  rr(c,69,y-31,48,48,12,p>.05?P.lime:'#29341F');if(p>.6)tick(c,93,y-7,23,P.black);else txt(c,'0'+(i+1),79,y+1,18,P.muted,600);
  txt(c,s,140,y,31,P.white,600);txt(c,detail[i],141,y+39,24,P.muted);c.restore();
 });c.restore();
 txt(c,'Цена и сроки — предварительно',43,1340,22,P.dim);
 rr(c,42,1400,554,100,19,'#12170D',P.line);
 const full='Сервис записи клиентов',typed=full.slice(0,Math.floor(sm((t-6.18)/.72)*full.length));
 txt(c,t<7.35?typed:'Написать сообщение',64,1463,29,t<7.35?P.white:P.dim,500);
 const hover=sm((t-7.0)/.12),pressed=t>=7.35&&t<7.50;
 c.save();c.translate(665,1450);let k=pressed?.94:1;c.scale(k,k);rr(c,-45,-50,90,100,20,hover>.1?P.lime:'#8FAF16');arrow(c,0,0,39,P.black);c.restore();
}

/** Draw the phone's manual queue, then the AI dialogue. t is global film time. */
export function drawPhone(ctx,t,W=750,H=1620,assets={}){
 ctx.save();ctx.scale(W/750,H/1620);phoneFrame(ctx);
 const p=sm((t-5.94)/.28);
 if(p<1){ctx.save();ctx.globalAlpha*=1-p;queuePhone(ctx,t);ctx.restore()}
 if(p>0){ctx.save();ctx.globalAlpha*=p;aiPhone(ctx,t);ctx.restore()}
 ctx.restore();return getUIAnchors(W,H,'phone');
}

/** Hotspots are in texture pixels and normalized coordinates for 3D projection. */
export function getUIAnchors(W,H,kind='catalog'){
 if(kind==='phone')return {send:{x:W*665/750,y:H*1450/1620,u:665/750,v:1450/1620},message:{x:W*.57,y:H*.38,u:.57,v:.38}};
 return {shopCard:{x:W*290/1536,y:H*783/960,u:290/1536,v:783/960},detailCTA:{x:W*1360/1536,y:H*857/960,u:1360/1536,v:857/960}};
}

export const UI_PALETTE={...P};
